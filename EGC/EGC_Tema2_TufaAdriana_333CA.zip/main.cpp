#include "lab_blackbox.hpp"
#include "lab_camera.hpp"


//time
#include <ctime>
#include <time.h> 


#define  KEY_ESCAPE		27
#define NUM_OBJ	13
#define MAX_JUMP 5
#define PACE 0.02f
#define PACE_JUMP 0.01f
#define ROTATION_PACE 90

class Laborator5
	: public lab::glut::WindowListener
{
private:
	struct ObjInfo{
		glm::vec3 centre;
		glm::vec3 dim; //height long width
	};


	typedef enum{XPOS, ZPOS, XNEG, ZNEG}direction_of_movement;
	// The BlackBox hides some functionality that we'll learn in the next course
	lab::BlackBox BLACKBOX;

	// Buffers used for holding state of keys
	// true - pressed
	// false - not pressed
	bool keyState[256];
	bool specialKeyState[256];

	// Objects
	lab::Mesh *obiect;
	lab::Mesh *cameraTarget;

	// Camera
	lab::Camera cameraTps, cameraFps;
	bool moveCameraToLeft = false, moveCameraToRight = false;
	float cameraAngle = 0;

	direction_of_movement move_direction = XPOS;

	// Projection matrix
	bool isPerspectiveProjection;
	glm::mat4 projectionMatrix, projectionMatrixFps;
	float FoV;
	float zNear, zFar;
	float aspectRatio;
	float orthoLeft, orthoRight, orthoTop, orthoBottom;

	lab::Mesh *objects_mesh[NUM_OBJ], *character;
	glm::vec3 colors_mesh[NUM_OBJ];
	glm::mat4  transf_char;
	ObjInfo objects[NUM_OBJ], me;

	float crtJump = 0;
	bool sits_on_smth = true;
	
public:
	Laborator5()
	{
		// init cameras
		cameraTps.set(glm::vec3(-9, 5, 29), glm::vec3(-9, 5, 9), glm::vec3(0, 1, 0));
		cameraFps.set(glm::vec3(-9, 5, 10), glm::vec3(-9, 5, 9), glm::vec3(0, 1, 0));

		// initializa all key states to not pressed
		memset(keyState, 0, 256);
		memset(specialKeyState, 0, 256);

		// Initialize default projection values
		zNear = 0.1f;
		zFar = 50.0f;
		FoV = 60.0f;
		aspectRatio = 800 / 600.0f;
		orthoLeft = -20;
		orthoRight = 20;
		orthoBottom = -20;
		orthoTop = 20;

		// value may be used for updating the projection when reshaping the window
		isPerspectiveProjection = true;

		projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoBottom, orthoTop, zNear, zFar);;
		projectionMatrixFps = glm::perspective(FoV, aspectRatio, zNear, zFar);

		transf_char = glm::translate(glm::mat4(1), glm::vec3(-9, 5, 9));
		me.centre = glm::vec3(-9, 5, 9);
		me.dim = glm::vec3(2, 2, 2);
		character = myLoadCube_as_Mesh(glm::vec3(0, 0, 0), me.dim);


		objects[0].centre = glm::vec3(0, 25, 0);
		objects[0].dim = glm::vec3(50, 10, 10);

		objects[1].centre = glm::vec3(-5.5, 2, 7);
		objects[1].dim = glm::vec3(4, 5, 4);

		objects[2].centre = glm::vec3(-2, 6.5, 6);
		objects[2].dim = glm::vec3(1, 7, 2);

		objects[3].centre = glm::vec3(5, 8.5, 6.5);
		objects[3].dim = glm::vec3(1, 6, 3);

		objects[4].centre = glm::vec3(6.5, 8.5, 0);
		objects[4].dim = glm::vec3(1, 3, 10);

		objects[5].centre = glm::vec3(4, 8.5, -7);
		objects[5].dim = glm::vec3(1, 8, 4);
		
		objects[6].centre = glm::vec3(-1.5, 9.5, -7);
		objects[6].dim = glm::vec3(3, 3, 4);

		objects[7].centre = glm::vec3(-5.5, 11, -7);
		objects[7].dim = glm::vec3(6, 5, 4);

		objects[8].centre = glm::vec3(-6.5, 13.5, 0);
		objects[8].dim = glm::vec3(1, 3, 10);

		objects[9].centre = glm::vec3(-4, 13.5, 6.5);
		objects[9].dim = glm::vec3(1, 8, 3);

		objects[10].centre = glm::vec3(3, 15.5, 6.5);
		objects[10].dim = glm::vec3(3, 3, 3);

		objects[11].centre = glm::vec3(-2.5, 19, 6.5);
		objects[11].dim = glm::vec3(1, 3, 3);

		objects[12].centre = glm::vec3(2, 25, 6.5);
		objects[12].dim = glm::vec3(2, 3, 3);


		srand(time(NULL));
		for (int i = 0; i < NUM_OBJ; i++) {
			objects_mesh[i] = myLoadCube_as_Mesh(objects[i].centre, objects[i].dim);
			colors_mesh[i] = glm::vec3((float)rand() / RAND_MAX,
				(float)rand() / RAND_MAX,
				(float)rand() / RAND_MAX);
		}
		colors_mesh[0] = glm::vec3(0.5f, 0.5f, 0.5f);

	}

	~Laborator5()
	{
		delete character;
		delete[] objects_mesh;
	}

	//---------------------------------------------------------------------
	// Loop Functions - function that are called every single frame

	// Called right before frame update callback (notifyDisplayFrame)
	void notifyBeginFrame() { };

	// Called every frame before we draw
	// Because glut sends only 1 key event every single frame, pressing more than 1 key will have no effect
	// If we treat the input using the 2 special buffers where we hold key states we can treat more than 1
	// key pressed at the same time. Also by not relling on glut to send the continuous pressing event
	// the moving motion will be more smooth because every single frame we apply the changes is contrast to
	// the event based method provided by Glut
	void treatInput()
	{
		//jump until the limit is reached
		if (keyState[' '] && crtJump < MAX_JUMP) { 
			moveCharUpward();
			if (crtJump >= MAX_JUMP) {
				sits_on_smth = false;
			}
		}
		
		if (!sits_on_smth) {
			moveCharDown();
		}

		//move to the right
		if (keyState['d']) { moveCharRight(); }
		//move to the left
		if (keyState['a']) { moveCharLeft(); }

		//rotate the camera with animation
		if (moveCameraToLeft && cameraAngle < 90) {
			cameraTps.rotateTPS_OY(-90/ROTATION_PACE);
			cameraFps.rotateFPS_OY(-90 / ROTATION_PACE);
			cameraAngle += 90 / ROTATION_PACE;
		}
		else if (moveCameraToLeft) {
			cameraAngle = 0;
			moveCameraLeft();
			moveCameraToLeft = false;
		}

		if (moveCameraToRight && cameraAngle < 90) {
			cameraAngle += 90 / ROTATION_PACE;
			cameraTps.rotateTPS_OY(90 / ROTATION_PACE);
			cameraFps.rotateFPS_OY(90 / ROTATION_PACE);
		}
		else if (moveCameraToRight) {
			cameraAngle = 0;
			moveCameraRight();
			moveCameraToRight = false;
		}
	}

	void moveCharDown() {
		// the object falls down until it reaches a surface
		if (canMove(glm::vec3(0, -PACE_JUMP, 0))) {
			transf_char = glm::translate(transf_char, glm::vec3(0, -PACE_JUMP, 0));
			cameraTps.translateUpword(-PACE_JUMP);
			cameraFps.translateUpword(-PACE_JUMP);
			me.centre += glm::vec3(0, -PACE_JUMP, 0);
		}
		else {
			// means it stopped on its way down
			sits_on_smth = true;
		}
	}

	/* The object jumps 
	   Returns true if it can jump */
	bool moveCharUpward() {
		if (canMove(glm::vec3(0, PACE_JUMP, 0))){
			transf_char = glm::translate(transf_char, glm::vec3(0, PACE_JUMP, 0));
			crtJump += PACE_JUMP;
			cameraTps.translateUpword(PACE_JUMP);
			cameraFps.translateUpword(PACE_JUMP);
			me.centre += glm::vec3(0, PACE_JUMP, 0);
			return true;
		}
		crtJump = MAX_JUMP;
		return false;
	}

	/* Move to the right according to where you are */
	void moveCharRight() {
		sits_on_smth = false;
		if (move_direction == XPOS && canMove(glm::vec3(PACE, 0, 0))) {
			transf_char = glm::translate(transf_char, glm::vec3(PACE, 0, 0));
			cameraTps.translateRight(PACE);
			cameraFps.translateRight(PACE);
			me.centre += glm::vec3(PACE, 0, 0);
		}
		else if (move_direction == ZPOS && canMove(glm::vec3(0, 0, PACE))) {
			transf_char = glm::translate(transf_char, glm::vec3(0, 0, PACE));
			cameraTps.translateRight(PACE);
			cameraFps.translateRight(PACE);
			me.centre += glm::vec3(0, 0, PACE);
		}
		else if (move_direction == XNEG  && canMove(glm::vec3(-PACE, 0, 0))){
			transf_char = glm::translate(transf_char, glm::vec3(-PACE, 0, 0));
			cameraTps.translateRight(PACE);
			cameraFps.translateRight(PACE);
			me.centre += glm::vec3(-PACE, 0, 0);
		}
		else if (move_direction == ZNEG && canMove(glm::vec3(0, 0, -PACE))){
			transf_char = glm::translate(transf_char, glm::vec3(0, 0, -PACE));
			cameraTps.translateRight(PACE);
			cameraFps.translateRight(PACE);
			me.centre += glm::vec3(0, 0, -PACE);
		}
		
	}

	/* Move to the left according to where you are */
	void moveCharLeft() {
		sits_on_smth = false;
		if (move_direction == XPOS && canMove(glm::vec3(-PACE, 0, 0))) {
			transf_char = glm::translate(transf_char, glm::vec3(-PACE, 0, 0));
			cameraTps.translateRight(-PACE);
			cameraFps.translateRight(-PACE);
			me.centre += glm::vec3(-PACE, 0, 0);
		}
		else if (move_direction == ZPOS && canMove(glm::vec3(0, 0, -PACE))) {
			transf_char = glm::translate(transf_char, glm::vec3(0, 0, -PACE));
			cameraTps.translateRight(-PACE);
			cameraFps.translateRight(-PACE);
			me.centre += glm::vec3(0, 0, -PACE);
		}
		else if (move_direction == XNEG && canMove(glm::vec3(PACE, 0, 0))){
			transf_char = glm::translate(transf_char, glm::vec3(PACE, 0, 0));
			cameraTps.translateRight(-PACE);
			cameraFps.translateRight(-PACE);
			me.centre += glm::vec3(PACE, 0, 0);
		}
		else if (move_direction == ZNEG && canMove(glm::vec3(0, 0, PACE))){
			transf_char = glm::translate(transf_char, glm::vec3(0, 0, PACE));
			cameraTps.translateRight(-PACE);
			cameraFps.translateRight(-PACE);
			me.centre += glm::vec3(0, 0, PACE);
		}
	}

	/* Change the direction of the camera */
	void moveCameraRight() {
		switch (move_direction) {
		case XPOS: {
			move_direction = ZNEG;
			break;
		    }
		case ZNEG: {
			move_direction = XNEG;
			break;
		}
		case XNEG: {
			move_direction = ZPOS;
			break;
		}
		case ZPOS: {
			move_direction = XPOS;
			break;
		}
		}
	}

	/* Change the direction of the camera */
	void moveCameraLeft() {
		switch (move_direction) {
		case XPOS: {
			move_direction = ZPOS;
			break;
		}
		case ZPOS: {
			move_direction = XNEG;
			break;
		}
		case XNEG: {
			move_direction = ZNEG;
			break;
		}
		case ZNEG: {
			move_direction = XPOS;
			break;
		}
		}
	}

	/* pas - how much you want to move
	   Returns true if the object can move with pas,
	   false otherwise */
	bool canMove(glm::vec3 pas) {
		glm::vec3 new_pos = me.centre + pas;
		for (int i = 0; i < NUM_OBJ; i++) {
			glm::vec3 dist = glm::abs(new_pos - objects[i].centre);
			glm::vec3 max_dist = me.dim / 2.0f + objects[i].dim / 2.0f;
			if (dist.x < max_dist[1] && dist.y < max_dist[0] && dist.z < max_dist[2]) {
				cout << "Interesectie cu obiectul " << i << "\n";
				return false;
			}
		}
		return true;
	}

	// A key was pressed
	void notifyKeyPressed(unsigned char key_pressed, int mouse_x, int mouse_y)
	{
		keyState[key_pressed] = 1;

		if (key_pressed == KEY_ESCAPE)
		{
			lab::glut::close();
		}

		// Set the projection matrix to Orthographic
		if (key_pressed == 'o')
		{
			isPerspectiveProjection = false;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoBottom, orthoTop, zNear, zFar);
		}

		// Set the projection matrix to Perspective 
		if (key_pressed == 'p')
		{
			isPerspectiveProjection = true;
			projectionMatrix = glm::perspective(FoV, aspectRatio, zNear, zFar);
		}
	}

	// When a key was released
	void notifyKeyReleased(unsigned char key_released, int mouse_x, int mouse_y)
	{
		keyState[key_released] = 0;

		if (key_released == ' ') {
			crtJump = 0;
			sits_on_smth = false;
		}
	}

	// Special key pressed like the navigation arrows or function keys F1, F2, ...
	void notifySpecialKeyPressed(int key_pressed, int mouse_x, int mouse_y)
	{
		specialKeyState[key_pressed] = 1;

		switch (key_pressed)
		{
		case GLUT_KEY_F1: {
			lab::glut::enterFullscreen();
			break;
		}

		case GLUT_KEY_F2: {
			lab::glut::exitFullscreen();
			break;
		}

		case GLUT_KEY_F5: {
			BLACKBOX.LoadShader();
			break;
		}

		case GLUT_KEY_LEFT: {
			moveCameraToLeft = true;
			break;
		}
		case GLUT_KEY_RIGHT:{
			moveCameraToRight = true;
			break;
		}
		default:
			break;
		}
	}

	// Called when a special key was released
	void notifySpecialKeyReleased(int key_released, int mouse_x, int mouse_y)
	{
		specialKeyState[key_released] = 0;
	}

	// Called every frame to draw
	void notifyDisplayFrame()
	{
		// Treat continuous input
		treatInput();

		glClearColor(1, 1, 1, 0);
		glClear(GL_COLOR_BUFFER_BIT);
		BLACKBOX.notifyDisplay();

		unsigned int width = lab::glut::getInitialWindowInformation().width;
		unsigned int height = lab::glut::getInitialWindowInformation().height;

		// ----------------------------------
		// Set the main viewport 
		glViewport(0, 0, 2*width/3, 2*height/3);

		// Send view matrix to the GPU
		BLACKBOX.setViewMatrix(cameraTps.getViewMatrix());

		// Send projection matrix to the GPU
		BLACKBOX.setProjectionMatrix(projectionMatrix);

		//draw the scene
		BLACKBOX.setModelMatrix(glm::mat4(1));
		for (int i = 0; i < NUM_OBJ; i++) {
			objects_mesh[i]->setColor(colors_mesh[i].r, colors_mesh[i].g, colors_mesh[i].b);
			BLACKBOX.drawMesh(objects_mesh[i]);
		}
		
		BLACKBOX.setModelMatrix(transf_char);
		BLACKBOX.drawMesh(character);


		// ----------------------------------
		// Set the second viewport 
		glViewport(2*width/3, 2*height/3, width/3, height/3);

		glClearColor(1, 1, 1, 0);
		BLACKBOX.notifyDisplay();

		BLACKBOX.setViewMatrix(cameraFps.getViewMatrix());
		BLACKBOX.setProjectionMatrix(projectionMatrixFps);

		//draw the scene
		BLACKBOX.setModelMatrix(glm::mat4(1));
		for (int i = 0; i < NUM_OBJ; i++) {
			objects_mesh[i]->setColor(colors_mesh[i].r, colors_mesh[i].g, colors_mesh[i].b);
			BLACKBOX.drawMesh(objects_mesh[i]);
		}
	}

	// Called when the frame ended
	void notifyEndFrame() { }

	//---------------------------------------------------------------------
	// Function called when the windows was resized
	void notifyReshape(int width, int height, int previos_width, int previous_height)
	{
		//blackbox needs to know
		BLACKBOX.notifyReshape(width, height);
		aspectRatio = (float)width / height;
	}

	//---------------------------------------------------------------------
	// Input function

	// Mouse drag, mouse button pressed 
	void notifyMouseDrag(int mouse_x, int mouse_y) { }

	// Mouse move without pressing any button
	void notifyMouseMove(int mouse_x, int mouse_y) { }

	// Mouse button click
	void notifyMouseClick(int button, int state, int mouse_x, int mouse_y) { }

	// Mouse scrolling
	void notifyMouseScroll(int wheel, int direction, int mouse_x, int mouse_y) { }


	/* Creeaza un dreptunghi din punctul (x,y) */
	lab::Mesh* myLoadCube_as_Mesh(glm::vec3 centre, glm::vec3 dim){
		float x = centre[0];
		float y = centre[1];
		float z = centre[2];
		float height = dim[0];
		float lung = dim[1];
		float width = dim[2];
		//definim containere pentru date
		std::vector<MyVertexFormat> vertecsi;
		std::vector<glm::uvec3> indecsi;

		//4 vertecsi (doar pozitii fara normale fara texcoords)
		vertecsi.clear();
		vertecsi.push_back(MyVertexFormat(x - lung / 2, y - height / 2, z + width / 2));//0
		vertecsi.push_back(MyVertexFormat(x + lung / 2, y - height / 2, z + width / 2));//1
		vertecsi.push_back(MyVertexFormat(x + lung / 2, y + height / 2, z + width / 2));//2
		vertecsi.push_back(MyVertexFormat(x - lung / 2, y + height / 2, z + width / 2));//3
		vertecsi.push_back(MyVertexFormat(x - lung / 2, y - height / 2, z - width / 2));//4
		vertecsi.push_back(MyVertexFormat(x + lung / 2, y - height / 2, z - width / 2));//5
		vertecsi.push_back(MyVertexFormat(x + lung / 2, y + height / 2, z - width / 2));//6
		vertecsi.push_back(MyVertexFormat(x - lung / 2, y + height / 2, z - width / 2));//7

		//2 triunghiuri pentru 1 fata
		indecsi.push_back(glm::uvec3(0, 1, 3));
		indecsi.push_back(glm::uvec3(3, 1, 2));
		indecsi.push_back(glm::uvec3(1, 5, 2));
		indecsi.push_back(glm::uvec3(2, 5, 6));
		indecsi.push_back(glm::uvec3(5, 6, 4));
		indecsi.push_back(glm::uvec3(4, 6, 7));
		indecsi.push_back(glm::uvec3(3, 7, 4));
		indecsi.push_back(glm::uvec3(0, 3, 4));
		indecsi.push_back(glm::uvec3(3, 2, 7));
		indecsi.push_back(glm::uvec3(7, 2, 6));
		indecsi.push_back(glm::uvec3(0, 1, 4));
		indecsi.push_back(glm::uvec3(1, 5, 4));

		//creaza vao
		unsigned int mesh_vao;
		glGenVertexArrays(1, &mesh_vao);
		glBindVertexArray(mesh_vao);

		//creeaza vbo
		unsigned int mesh_vbo;
		glGenBuffers(1, &mesh_vbo);
		glBindBuffer(GL_ARRAY_BUFFER, mesh_vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(MyVertexFormat)*vertecsi.size(), &vertecsi[0], GL_STATIC_DRAW);

		//creeaza ibo
		unsigned int mesh_ibo;
		glGenBuffers(1, &mesh_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh_ibo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(glm::uvec3)*indecsi.size(), &indecsi[0], GL_STATIC_DRAW);

		//creez obiect de tip mesh
		lab::Mesh* mesh = new lab::Mesh(mesh_vbo, mesh_ibo, mesh_vao, indecsi.size() * 3);

		// traducem la OpenGL cum sa foloseasca datele noastre
		BLACKBOX.bindMesh(mesh, sizeof(MyVertexFormat));

		//return
		return mesh;
	}

	//format vertex de mana
	struct MyVertexFormat{
		glm::vec3 pozitie;
		MyVertexFormat(){
			pozitie = glm::vec3(0, 0, 0);
		}
		MyVertexFormat(float px, float py, float pz){
			pozitie = glm::vec3(px, py, pz);
		}
		MyVertexFormat operator=(const MyVertexFormat &rhs){
			pozitie = rhs.pozitie;
			return (*this);
		}
	};
};

int main()
{
	// Initialize GLUT: window + input + OpenGL context
	lab::glut::WindowInfo window(std::string("EGC Laborator 5 - Camera and Projections"), 800, 600, 600, 100, true);
	lab::glut::ContextInfo context(3, 3, false);
	lab::glut::FramebufferInfo framebuffer(true, true, false, false);
	lab::glut::init(window, context, framebuffer);

	// Initialize GLEW + load OpenGL extensions 
	glewExperimental = true;
	glewInit();
	std::cout << "[GLEW] : initializare" << std::endl;

	// Create a new instance of Lab and listen for OpenGL callback
	// Must be created after GLEW because we need OpenGL extensions to be loaded

	Laborator5 *lab5 = new Laborator5();
	lab::glut::setListener(lab5);

	// Enter loop
	lab::glut::run();

	return 0;
}