//-------------------------------------------------------------------------------------------------
// Descriere: fisier main
//
// Autor: student
// Data: today
//-------------------------------------------------------------------------------------------------

//librarie matematica 
#include "..\\dependente\glew\glew.h"
#include "..\\dependente\glm\glm.hpp"
#include "..\\dependente\glm\gtc\type_ptr.hpp"
#include "..\\dependente\glm\gtc\matrix_transform.hpp"

//neimportant pentru acest laborator, va fi explicat in viitor
#include "..\\lab_blackbox.hpp"

//interfata cu glut, ne ofera fereastra, input, context opengl
#include "..\\lab_glut.hpp"

//time
#include <ctime>

#include <iostream>
#include <time.h> 

#define NR_OBJ_MESH 13
#define NR_OBJ 11
#define NR_MAX_RAZE 25

//clasa lab, mosteneste din WindowListener
class Lab : public lab::glut::WindowListener{

//variabile
private:
	//un obiect ce ascunde functii pe care vom ajunge sa le scriem de mana.
	lab::BlackBox BLACKBOX;

	// structura pentru un punct
	struct Point {
		float x, y;
		Point() {}
		Point(float px, float py) {
			x = px;
			y = py;
		}
	};

	// obiect pentru a desena sursa de lumina
	lab::Polyline *lumina;
	glm::mat3 transf_lum;

	// scena si obiectele din ea
	lab::Mesh *incadrator, *scena, *obiecteM[NR_OBJ_MESH];
	// vector de puncte pentru fiecare obiect desenat
	std::vector<std::vector<Point>> puncte;
	// culorile fiecarui obiect
	std::vector<glm::vec3> colors;

	// vector pentr raze
	lab::Mesh *raza[NR_MAX_RAZE];
    // cate raze se deseneaza
	int nr_raze = NR_MAX_RAZE;
	// unghiul fiecarei raze fata de axa Ox pozitiva
	float angle[NR_MAX_RAZE];
	// punctul de start al fiecarei raze
	Point start_raza[NR_MAX_RAZE];
	// vector de culori
	glm::vec3 color_raza[NR_MAX_RAZE];
	// matricile de tranformare pentru raze
	glm::mat3 transf_raza[NR_MAX_RAZE];
	// ne spune daca o raza trebuie desenata sau nu
	int enable[NR_MAX_RAZE];
	// lungimea fiecarei raze
	float max_d[NR_MAX_RAZE];
	// lungimea curenta a razelor in timp ce sunt desenate
	float d[NR_MAX_RAZE];
	// variabila folosita atunci cand se schimba directia primei raze
	bool redraw;

	unsigned int width, height;
	int count_frame = 0;
	
	
//metode ale clasei lab
public:
	
	//constructor .. e apelat cand e instantiata clasa
	Lab(){
		srand(time(NULL));

		//initializari
		width = lab::glut::getInitialWindowInformation().width;
		height = lab::glut::getInitialWindowInformation().height;

		transf_lum = glm::mat3(1);
		redraw = false;

		// initializari pentru raze
		for (int i = 0; i < NR_MAX_RAZE; i++) {
			angle[i] = 0;
			start_raza[i] = Point(0, 0);
			enable[i] = 0;
			max_d[i] = 0;
			d[i] = 0; 
			transf_raza[i] = myIdentity();
		}
		start_raza[0] = Point(300, 300);
		d[0] = 20;
		enable[0] = 1;
		color_raza[0] = glm::vec3(1, 1, 0);

		// initializari pentru culori
		for (int i = 0; i < NR_OBJ; i++) {
			glm::vec3 v = glm::vec3((float)rand() / RAND_MAX, 
				                    (float)rand() / RAND_MAX, 
									(float)rand() / RAND_MAX);
			colors.push_back(v);
		}
		// ultimul obiect este camera si trebuie sa fie negru
		colors[NR_OBJ-1] = glm::vec3(0, 0, 0);	

		// intializari pentru obiecte
		incadrator = myLoadRectangle_as_Mesh(0, 0, 1000, 600);
		scena = myLoadRectangle_as_Mesh(10, 10, 980, 580);
		lumina = myLoadTriangle_as_Polyline(300, 300, 30);
		raza[0] = myLoadRectangle_as_Mesh(300, 297.5, 20, 5);

		// pun in vectorul de puncte coordonatele fiecarei laturi
		std::vector <Point> puncte0;
		puncte0.push_back(Point(10, 440));
		puncte0.push_back(Point(210, 440));
		puncte0.push_back(Point(210, 590));
		puncte0.push_back(Point(10, 590));
		puncte0.push_back(Point(10, 440));
		puncte.push_back(puncte0);
		obiecteM[0] = myLoadRectangle_as_Mesh(10, 440, 200, 150);

		std::vector <Point> puncte1;
		puncte1.push_back(Point(10, 230));
		puncte1.push_back(Point(100, 230));
		puncte1.push_back(Point(100, 380));
		puncte1.push_back(Point(10, 380));
		puncte1.push_back(Point(10, 230));
		puncte.push_back(puncte1);
		obiecteM[1] = myLoadRectangle_as_Mesh(10, 230, 90, 150);

		std::vector <Point> puncte2;
		puncte2.push_back(Point(10, 10));
		puncte2.push_back(Point(220, 10));
		puncte2.push_back(Point(220, 60));
		puncte2.push_back(Point(10, 60));
		puncte2.push_back(Point(10, 10));
		puncte.push_back(puncte2);
		obiecteM[2] = myLoadRectangle_as_Mesh(10, 10, 210, 50);

		std::vector <Point> puncte3;
		puncte3.push_back(Point(250, 10));
		puncte3.push_back(Point(420, 10));
		puncte3.push_back(Point(420, 210));
		puncte3.push_back(Point(400, 210));
		puncte3.push_back(Point(400, 50));
		puncte3.push_back(Point(250, 50));
		puncte3.push_back(Point(250, 10));
		puncte.push_back(puncte3);
		obiecteM[3] = myLoadRectangle_as_Mesh(250, 10, 150, 50);
		obiecteM[4] = myLoadRectangle_as_Mesh(400, 10, 20, 200);

		std::vector <Point> puncte4;
		puncte4.push_back(Point(560, 100));
		puncte4.push_back(Point(650, 100));
		puncte4.push_back(Point(650, 150));
		puncte4.push_back(Point(560, 150));
		puncte4.push_back(Point(560, 100));
		puncte.push_back(puncte4);
		obiecteM[5] = myLoadRectangle_as_Mesh(560, 100, 90, 50);

		std::vector <Point> puncte5;
		puncte5.push_back(Point(790, 10));
		puncte5.push_back(Point(990, 10));
		puncte5.push_back(Point(990, 220));
		puncte5.push_back(Point(910, 220));
		puncte5.push_back(Point(910, 160));
		puncte5.push_back(Point(790, 160));
		puncte5.push_back(Point(790, 10));
		puncte.push_back(puncte5);
		obiecteM[6] = myLoadRectangle_as_Mesh(790, 10, 120, 150);
		obiecteM[7] = myLoadRectangle_as_Mesh(910, 10, 80, 210);

		std::vector <Point> puncte6;
		puncte6.push_back(Point(920, 300));
		puncte6.push_back(Point(990, 300));
		puncte6.push_back(Point(990, 400));
		puncte6.push_back(Point(920, 400));
		puncte6.push_back(Point(920, 300));
		puncte.push_back(puncte6);
		obiecteM[8] = myLoadRectangle_as_Mesh(920, 300, 70, 100);

		std::vector <Point> puncte7;
		puncte7.push_back(Point(550, 400));
		puncte7.push_back(Point(580, 400));
		puncte7.push_back(Point(580, 590));
		puncte7.push_back(Point(550, 590));
		puncte7.push_back(Point(550, 400));
		puncte.push_back(puncte7);
		obiecteM[9] = myLoadRectangle_as_Mesh(550, 400, 30, 190);

		std::vector <Point> puncte8;
		puncte8.push_back(Point(630, 450));
		puncte8.push_back(Point(680, 450));
		puncte8.push_back(Point(680, 500));
		puncte8.push_back(Point(630, 500));
		puncte8.push_back(Point(630, 450));
		puncte.push_back(puncte8);
		obiecteM[10] = myLoadRectangle_as_Mesh(630, 450, 50, 50);

		std::vector <Point> puncte9;
		puncte9.push_back(Point(260, 500));
		puncte9.push_back(Point(260, 550));
		puncte9.push_back(Point(480, 550));
		puncte9.push_back(Point(480, 500));
		puncte9.push_back(Point(260, 500));
		puncte.push_back(puncte9);
		obiecteM[11] = myLoadRectangle_as_Mesh(260, 500, 220, 50);

		//camera
		std::vector <Point> puncte10;
		puncte10.push_back(Point(990, 590));
		puncte10.push_back(Point(990, 490));
		puncte10.push_back(Point(890, 590));
		obiecteM[12] = myLoadTriangle_as_Mesh(puncte10);
		puncte10.push_back(Point(990, 590));
		puncte.push_back(puncte10);

		compute_directions();
	}

	//destructor .. e apelat cand e distrusa clasa
	~Lab(){
		delete incadrator;
		delete scena;
		delete lumina;
		for (int i = 0; i < NR_OBJ_MESH; i++) {
			delete obiecteM[i];
		}
	}

	//format vertex de mana
	struct MyVertexFormat{
		glm::vec2 pozitie;
		MyVertexFormat(){
			pozitie = glm::vec2(0, 0);
		}
		MyVertexFormat(float px, float py){
			pozitie = glm::vec2(px, py);
		}
		MyVertexFormat operator=(const MyVertexFormat &rhs){
			pozitie = rhs.pozitie;
			return (*this);
		}
	};



	//--------------------------------------------------------------------------------------------
	//functii de transformare --------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------
	glm::mat3 myIdentity(){
		return glm::transpose(glm::mat3(
			1, 0, 0,						
			0, 1, 0,
			0, 0, 1
			));
	}
	glm::mat3 myTranslate(float tx, float ty){
		return glm::mat3(
			1, 0, 0,
			0, 1, 0,
			tx, ty, 1);
	}
	glm::mat3 myRotate(float u){
		return glm::mat3(
			cos(u), sin(u), 0,
			-sin(u), cos(u), 0,
			0, 0, 1);
	}
	glm::mat3 myScale(float sx, float sy){
		return glm::mat3(
			sx, 0, 0,
			0, sy, 0,
			0, 0, 1);
	}

	//--------------------------------------------------------------------------------------------
	//functii de cadru, apelate per FIECARE cadru ------------------------------------------------
	//--------------------------------------------------------------------------------------------
	//functie chemata inainte de a incepe cadrul de desenare
	void notifyBeginFrame(){
		// reinitializari daca toate razele trebuie redesenate
		if (redraw) {
			d[0] = 20;
			redraw = false;
			enable[0] = 1;
			for (int i = 1; i < NR_MAX_RAZE; i++) {
				enable[i] = 0; //celalte raze se sterg
				d[i] = 0;
			}
		}

		start_raza[0].x = 300;
		for (int i = 0; i < nr_raze; i++) {
			// daca raza trebuie desenata si inca nu a ajuns la lungimea finala
			if (enable[i] && d[i] < max_d[i]) {
				if (d[i] == 0) {
					d[i] = 10; //lungimea initiala
				}
				// sterg obiectul deja desenat
				if (raza[i]) delete raza[i]; 
				// redesenez raza cu o noua dimensiune
				raza[i] = myLoadRectangle_as_Mesh(start_raza[i].x, 
					                        start_raza[i].y - 2.5, d[i], 5);
				transf_raza[i] = myTranslate(start_raza[i].x, start_raza[i].y) *
					             myRotate(angle[i]) * 
								 myTranslate(-start_raza[i].x, -start_raza[i].y);
			}
		}
	}
	//functia de afisare
	void notifyDisplayFrame(){
		//per ECRAN
		//bufferele din framebuffer sunt aduse la valorile initiale (setate de clear color)
		//adica se sterge ecranul si se pune culoarea initiala (si alte propietati)
		glClearColor(1, 1, 1, 0);			//la ce culoare sterg
		glClear(GL_COLOR_BUFFER_BIT);		//comanda de stergere
		BLACKBOX.notifyDisplay();

		//setez spatiul de desenare relativ la spatiul ecranului
		width = lab::glut::getInitialWindowInformation().width;
		height = lab::glut::getInitialWindowInformation().height;

		//viewport 
		glViewport(0, 0, width, height);
        
		// desenez obiectele din scena
		BLACKBOX.setModelMatrix(myIdentity());
		for (int i = 0; i < 4; i++) {
			obiecteM[i]->setColor(colors[i].r, colors[i].g, colors[i].b);
			BLACKBOX.drawMesh(obiecteM[i], 1);
		}
		for (int i = 4; i < 7; i++) {
			obiecteM[i]->setColor(colors[i-1].r, colors[i-1].g, colors[i-1].b);
			BLACKBOX.drawMesh(obiecteM[i], 1);
		}
		for (int i = 7; i < NR_OBJ_MESH; i++) {
			obiecteM[i]->setColor(colors[i - 2].r, colors[i - 2].g, colors[i - 2].b);
			BLACKBOX.drawMesh(obiecteM[i], 1);
		}
		
		// desenz sursa de lumina ca un triunghi rotit
		lumina->setColor(1, 1, 0);
		for (int i = 0; i < 200; i++) {
			transf_lum *= myTranslate(300, 300)* myRotate(2 * glm::pi<float>() / 200)* myTranslate(-300, -300);
			BLACKBOX.setModelMatrix(transf_lum);
			BLACKBOX.drawPolyline(lumina);
		}

		// desenez razele
		for (int i = 0; i < nr_raze; i++){
			if (enable[i]) {
				raza[i]->setColor(color_raza[i].r, color_raza[i].g,
					color_raza[i].b);

				// daca lungimea razei nu e maxima, o incrementez
				if (d[i] < max_d[i]) {
					d[i] += 2;
				}
				// daca nu, "activez" urmatoarea raza
				else {
					if (i + 1 < NR_MAX_RAZE && enable[i + 1] == 0) {
						enable[i + 1] = 1;
						break;
					}
				}
				// desenez raza
				BLACKBOX.setModelMatrix(transf_raza[i]);
				BLACKBOX.drawMesh(raza[i], 1);
			}
		}

		scena->setColor(0.5f, 0.5f, 0.5f);
		BLACKBOX.setModelMatrix(myIdentity());
		BLACKBOX.drawMesh(scena, 1);

		incadrator->setColor(0, 0, 0);
		BLACKBOX.drawMesh(incadrator, 1);
	}

	//functie chemata dupa ce am terminat cadrul de desenare (poate fi folosita pt modelare/simulare)
	void notifyEndFrame(){}

	//functie care e chemata cand se schimba dimensiunea ferestrei initiale
	void notifyReshape(int width, int height, int previos_width, int previous_height){
		//blackbox needs to know
		BLACKBOX.notifyReshape(width,height);
	}

	/* Verifica daca r este pe directia data de orig si angle
	   orig -> punctul de start al unei raze
	   angle -> unghiul razei cu axa Ox pozitiva
	   r -> punctul de intersectie al razei cu o dreapta */
	bool verify_direction(Point orig, float angle, Point r) {
		double sinus = sin(angle);
		double cosinus = cos(angle);

		// impart planul in 4 cadrane cu centrul in orig.
		// daca directia e buna, atunci unghiul si punctul r
		// se afla in acelasi cadran
		if (cosinus >= 0) {
			if (sinus >= 0) { //cadranul 1
				return r.x >= orig.x && r.y >= orig.y;
			}
			else { //cadranul 4
				return r.x >= orig.x && r.y <= orig.y;
			}
		}
		else {
			if (sinus >= 0) { //cadranul 2
				return r.x <= orig.x && r.y >= orig.y;
			}
			else { //cadranul 3
				return r.x <= orig.x && r.y <= orig.y;
			}
		}
	}

	/* Verifica daca r se afla pe segmentul [p1 p2] */
	bool verify_segment(Point p1, Point p2, Point r) {
		return abs(abs(p1.x - p2.x) - abs(p1.x - r.x) - abs(r.x - p2.x)) < 0.1 &&
			   abs(abs(p1.y - p2.y) - abs(p1.y - r.y) - abs(r.y - p2.y)) < 0.1;
	}

	/* Calculeaza punctul de intersectie a 2 drepte date de puncte p1 si p2, p3 si p4*/
	Point compute_intersection(Point p1, Point p2, Point p3, Point p4, float angle) {
		Point r;
		r.x = ((p1.x * p2.y - p2.x * p1.y) * (p3.x - p4.x) - 
			   (p3.x * p4.y - p4.x * p3.y) * (p1.x - p2.x)) /
			  ((p1.x - p2.x) * (p3.y - p4.y) - (p3.x - p4.x) * (p1.y - p2.y));
		r.y = ((p1.x * p2.y - p2.x * p1.y) * (p3.y - p4.y) - 
			   (p3.x * p4.y - p4.x * p3.y) * (p1.y - p2.y)) /
			  ((p1.x - p2.x) * (p3.y - p4.y) - (p3.x - p4.x) * (p1.y - p2.y));

		// daca liniile sun paralele
		if (r.x == 0 || r.y == 0)
			return Point(0, 0);
		// verific daca punctul este valid
		if (verify_direction(p1, angle, r) &&
			verify_segment(p3, p4, r))
			return r;

		return Point(0,0);
	}

	/* Calculeaza distanta dintre 2 puncte */
	float compute_distance(Point a, Point b) {
		return sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
	}

	/* Calculeaza toate informatiile necesare pentru trasarea razelor */
	void compute_directions() {
		float aux_dist;
		//indexul obiectului (din vectorul puncte) cu care se intersecteaza
		float index = -1; 
		Point intersect;
		// mariginile segmentului cu care se intersecteaza raza
		Point dreapta[2];

		color_raza[0] = glm::vec3(1, 1, 0);
		nr_raze = NR_MAX_RAZE;

		for (int i = 0; i < NR_MAX_RAZE; i++) {
			float min_dist = 99999;
			Point min_point;
			index = -1;
			// 2 pct de pe raza curenta
			Point a1 = start_raza[i];
			Point a2 = Point(a1.x+2*cos(angle[i]), 
				             a1.y+2*sin(angle[i]));
			glm::vec3 color;

			// calculez intersectia cu toate dreptele desenate
			for (int j = 0; j < NR_OBJ; j++) {
				int size = puncte[j].size();

				for (int k = 0; k < size - 1; k++) {
					intersect = compute_intersection(a1, a2, puncte[j][k],
						             puncte[j][k + 1], angle[i]);
					// daca punctul este valid
					if (intersect.x != 0) {
						aux_dist = compute_distance(start_raza[i], intersect);
						// verific daca distanta e minima
						// compar distanta cu 1 deoarece se poate intampla ca ea sa fie
						// subunitara, caz pe care nu il iau in considerare
						if (aux_dist > 1 && aux_dist < min_dist) {
							min_dist = aux_dist;
							min_point = intersect;
							dreapta[0] = puncte[j][k];
							dreapta[1] = puncte[j][k + 1];
							color = colors[j];
							index = j;
						}
					}
				}
			}
			//verific intersectia cu chenarul
			intersect = compute_intersection(a1, a2, 
					        Point(10, 10), Point(990, 10), angle[i]);
			if (intersect.x != 0) {
				aux_dist = compute_distance(start_raza[i], intersect);
				if (aux_dist > 0 && aux_dist < min_dist && aux_dist > 1) {
					min_dist = aux_dist;
					min_point = intersect;
					dreapta[0] = Point(10, 10);
					dreapta[1] = Point(990, 10);
					color = glm::vec3(0, 0, 0);
				}
			}
			intersect = compute_intersection(a1, a2,
					        Point(990, 10), Point(990, 590), angle[i]);
			if (intersect.x != 0) {
				aux_dist = compute_distance(start_raza[i], intersect);
				if (aux_dist > 0 && aux_dist < min_dist && aux_dist > 1) {
					min_dist = aux_dist;
					min_point = intersect;
					dreapta[0] = Point(990, 10);
					dreapta[1] = Point(990, 590);
					color = glm::vec3(0, 0, 0);
				}
			}
			intersect = compute_intersection(a1, a2,
					        Point(990, 590), Point(10, 590), angle[i]);
			if (intersect.x != 0) {
				aux_dist = compute_distance(start_raza[i], intersect);
				if (aux_dist > 0 && aux_dist < min_dist && aux_dist > 1) {
					min_dist = aux_dist;
					min_point = intersect;
					dreapta[0] = Point(990, 590);
					dreapta[1] = Point(10, 590);
					color = glm::vec3(0, 0, 0);
				}
			}
			intersect = compute_intersection(a1, a2,
					        Point(10, 590), Point(10, 10), angle[i]);
			if (intersect.x != 0) {
				aux_dist = compute_distance(start_raza[i], intersect);
				if (aux_dist > 0 && aux_dist < min_dist && aux_dist > 1) {
					min_dist = aux_dist;
					min_point = intersect;
					dreapta[0] = Point(10, 590);
					dreapta[1] = Point(10, 10);
					color = glm::vec3(0, 0, 0);
				}
			}
			
			// setez lungimea razei
			max_d[i] = min_dist;
			
			// daca se intersecteaza cu camera, urmatoarele raze nu vor mai fi desenate
			if (index == 10) {
				nr_raze = glm::min(i + 1, NR_MAX_RAZE);
				return;
			}

			if (i < NR_MAX_RAZE - 1) {
				start_raza[i + 1] = min_point;
				color_raza[i + 1] = glm::vec3((color.r + color_raza[i].r) / 2, 
					                          (color.g + color_raza[i].g) / 2,
											  (color.b + color_raza[i].b) / 2);
				
				// calculez unghiul urmatoarei raze astfel:
				// 1. translatez punctul de intersectie in origine
				// 2. formez cei 2 vectori - raza incidenta si planul pt glm::reflect
				// 3. calculez unghiul razei reflectate fata de Ox

				// raza incidenta
				glm::vec2 I = glm::vec2(-min_point.x+start_raza[i].x, -min_point.y+start_raza[i].y);
				// planul de intersectie
				glm::vec2 N = glm::vec2(dreapta[1].x-dreapta[0].x, dreapta[1].y-dreapta[0].y);
				// raza reflectata in origine
				glm::vec2 red = glm::reflect(I, glm::normalize(N));
				// cosinusul unghiului facut de raza reflectata cu Ox
				float t = abs(red.x) / sqrt(red.y*red.y + red.x*red.x);
				// unghiul razei reflectate (intre 0 si pi/2)
				float unghi_t = acos(t);
				
				// setez unghiul razei reflectate fata de axa Ox pozitiva
				if (red.x >= 0) {
					if (red.y >= 0) {//cadran 1
						angle[i + 1] = unghi_t;
					}
					else { //cadran 4
						angle[i + 1] = 2 * glm::pi<float>() - unghi_t;
					}
				}
				else {
					if (red.y >= 0) { //cadran 2
						angle[i + 1] = glm::pi<float>() - unghi_t;
					}
					else { //cadran 3
						angle[i + 1] = glm::pi<float>() + unghi_t;
					}
				}
				
			}
		}
	}
	
	//--------------------------------------------------------------------------------------------
	//functii de input output --------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------
	//tasta apasata
	void notifyKeyPressed(unsigned char key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == 27) lab::glut::close();	//ESC inchide glut si 
	}

	//tasta ridicata
	void notifyKeyReleased(unsigned char key_released, int mouse_x, int mouse_y){}

	//tasta speciala (up/down/F1/F2..) apasata
	void notifySpecialKeyPressed(int key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == GLUT_KEY_F1) lab::glut::enterFullscreen();
		if(key_pressed == GLUT_KEY_F2) lab::glut::exitFullscreen();
		// incrementeaza unghiul primei raze
		if (key_pressed == GLUT_KEY_DOWN) {
			angle[0] -= 0.1f;
			redraw = true; // sterge razele
			compute_directions(); // calculeaza noile valori pentru raze
		}
		// decrementeaza unghiul primei raze
		if (key_pressed == GLUT_KEY_UP) {
			angle[0] += 0.1f;
			redraw = true; // sterge razele
			compute_directions(); // calculeaza noile valori pentru raze
		}
		
	}

	//tasta speciala ridicata
	void notifySpecialKeyReleased(int key_released, int mouse_x, int mouse_y){}
	//drag cu mouse-ul
	void notifyMouseDrag(int mouse_x, int mouse_y){ }
	//am miscat mouseul (fara sa apas vreun buton)
	void notifyMouseMove(int mouse_x, int mouse_y){ }
	//am apasat pe un boton
	void notifyMouseClick(int button, int state, int mouse_x, int mouse_y){ }
	//scroll cu mouse-ul
	void notifyMouseScroll(int wheel, int direction, int mouse_x, int mouse_y){ std::cout<<"Mouse scroll"<<std::endl;}

	/* Creeaza un dreptunghi din punctul (x,y) */
	lab::Mesh* myLoadRectangle_as_Mesh(float x, float y, float lungime, float latime){
		//definim containere pentru date
		std::vector<MyVertexFormat> vertecsi;
		std::vector<glm::uvec3> indecsi;

		//4 vertecsi (doar pozitii fara normale fara texcoords)
		vertecsi.push_back(MyVertexFormat(x, y));
		vertecsi.push_back(MyVertexFormat(x + lungime, y));
		vertecsi.push_back(MyVertexFormat(x + lungime, y + latime));
		vertecsi.push_back(MyVertexFormat(x, y + latime));

		//2 triunghiuri pentru 1 fata
		indecsi.push_back(glm::uvec3(0, 1, 2));	indecsi.push_back(glm::uvec3(2, 3, 0));

		//creaza vao
		unsigned int mesh_vao;
		glGenVertexArrays(1, &mesh_vao);
		glBindVertexArray(mesh_vao);

		//creeaza vbo
		unsigned int mesh_vbo;
		glGenBuffers(1, &mesh_vbo);
		glBindBuffer(GL_ARRAY_BUFFER, mesh_vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(MyVertexFormat)*vertecsi.size(), &vertecsi[0], GL_STATIC_DRAW);

		//creeaza ibo
		unsigned int mesh_ibo;
		glGenBuffers(1, &mesh_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh_ibo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int)*indecsi.size() * 3, &indecsi[0], GL_STATIC_DRAW);

		//creez obiect de tip mesh
		lab::Mesh* mesh = new lab::Mesh(mesh_vbo, mesh_ibo, mesh_vao, indecsi.size() * 3);

		// traducem la OpenGL cum sa foloseasca datele noastre
		BLACKBOX.bindMesh(mesh, sizeof(MyVertexFormat));

		//return
		return mesh;
	}

	/* Creeaza un triunghi dupa vectorul de coordonate */
	lab::Mesh* myLoadTriangle_as_Mesh(std::vector<Point> puncte){
		//definim containere pentru date
		std::vector<MyVertexFormat> vertecsi;
		std::vector<glm::uvec3> indecsi;

		//4 vertecsi (doar pozitii fara normale fara texcoords)
		vertecsi.push_back(MyVertexFormat(puncte[0].x, puncte[0].y));
		vertecsi.push_back(MyVertexFormat(puncte[1].x, puncte[1].y));
		vertecsi.push_back(MyVertexFormat(puncte[2].x, puncte[2].y));

		//2 triunghiuri pentru 1 fata
		indecsi.push_back(glm::uvec3(0, 1, 2));

		//creaza vao
		unsigned int mesh_vao;
		glGenVertexArrays(1, &mesh_vao);
		glBindVertexArray(mesh_vao);

		//creeaza vbo
		unsigned int mesh_vbo;
		glGenBuffers(1, &mesh_vbo);
		glBindBuffer(GL_ARRAY_BUFFER, mesh_vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(MyVertexFormat)*vertecsi.size(), &vertecsi[0], GL_STATIC_DRAW);

		//creeaza ibo
		unsigned int mesh_ibo;
		glGenBuffers(1, &mesh_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh_ibo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int)*indecsi.size() * 3, &indecsi[0], GL_STATIC_DRAW);

		//creez obiect de tip mesh
		lab::Mesh* mesh = new lab::Mesh(mesh_vbo, mesh_ibo, mesh_vao, indecsi.size() * 3);

		// traducem la OpenGL cum sa foloseasca datele noastre
		BLACKBOX.bindMesh(mesh, sizeof(MyVertexFormat));

		//return
		return mesh;
	}

	/* Creeaza un triunghi din (x,y) cu raza data */
	lab::Polyline* myLoadTriangle_as_Polyline(float x, float y, float raza){

		//definim containere pentru date
		std::vector<MyVertexFormat> vertecsi;
		std::vector<unsigned int> indecsi; //nu mai dau cate trei indici, pentru ca nu mai desenez triunghiuri, ci LINE_STRIP, adica segmente conectate

		//4 vertecsi (doar pozitii fara normale fara texcoords)
		vertecsi.push_back(MyVertexFormat(x, y));
		vertecsi.push_back(MyVertexFormat(x + raza, y-raza/2));
		vertecsi.push_back(MyVertexFormat(x + raza, y + raza/2));

		//insiruirea punctelor (daca dorim sa obtinem un patrat, primul punct se pune si la sfarsit, ca sa se inchida polilinia)
		indecsi.push_back(0);
		indecsi.push_back(1);
		indecsi.push_back(2);
		indecsi.push_back(0);

		//creaza vao
		unsigned int polyline_vao;
		glGenVertexArrays(1, &polyline_vao);
		glBindVertexArray(polyline_vao);

		//creeaza vbo
		unsigned int polyline_vbo;
		glGenBuffers(1, &polyline_vbo);
		glBindBuffer(GL_ARRAY_BUFFER, polyline_vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(MyVertexFormat)*vertecsi.size(), &vertecsi[0], GL_STATIC_DRAW);

		//creeaza ibo
		unsigned int polyline_ibo;
		glGenBuffers(1, &polyline_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, polyline_ibo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int)*indecsi.size(), &indecsi[0], GL_STATIC_DRAW);

		//creez obiect de tip polilinie
		lab::Polyline* polyline = new lab::Polyline(polyline_vbo, polyline_ibo, polyline_vao, indecsi.size() * 3);

		// traducem la OpenGL cum sa foloseasca datele noastre
		BLACKBOX.bindPolyline(polyline, sizeof(MyVertexFormat));

		//return
		return polyline;
	}
};

int main(){
	//initializeaza GLUT (fereastra + input + context OpenGL)
	lab::glut::WindowInfo window(std::string("Lab EGC 3 - transformari"),1000,600,300,50,true);
	lab::glut::ContextInfo context(3,3,false);
	lab::glut::FramebufferInfo framebuffer(true,true,false,false);
	lab::glut::init(window, context, framebuffer);

	//initializeaza GLEW (ne incarca functiile openGL, altfel ar trebui sa facem asta manual!)
	glewExperimental = true;
	glewInit();
	std::cout<<"GLEW:initializare"<<std::endl;

	//creem clasa noastra si o punem sa asculte evenimentele de la GLUT
	//_DUPA_ GLEW ca sa avem functiile de OpenGL incarcate inainte sa ii fie apelat constructorul (care creeaza obiecte OpenGL)
	Lab mylab;
	lab::glut::setListener(&mylab);

	//run
	lab::glut::run();

	return 0;
}