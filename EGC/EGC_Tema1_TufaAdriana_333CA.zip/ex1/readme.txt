// Tufa Adriana 333 CA
// Tema 1 EGC

  Implementarea am inceput-o de la scheletul din laboratorul 3.
Pentru a desena obiectele din scena am folosit mesh-uri. Sursa de lumina am
desenat-o folosind un triunghi ce se roteste cu un unghi foarte mic in jurul
varfului sau. Pentru a putea calcula intersectiile am retinut pentru fiecare obiect
coordonatele varfurilor laturilor sale, in ordine, astfel incat daca iau 2 cate 
2 puncte din vector voi obtine toate laturile. 
  Razele le-am desenat folosind dreptunghiuri din ce in ce mai mari. La fiecare
cadru maresc lungimea razei pana se ajunge la punctul de intersectie si o redesenez.
Fiecare raza e caracterizata de punctul de start, unghiul fata de axa Ox pozitiva si
lungimea pana la prima intersectie. Astfel la fiecare cadru desenez un dreptunghi
rotit fata de punctul de start.
  Punctele de intersectie, unghiurile si lungimile razelor le calculez o singura data,
la inceput sau atunci cand se schimba directia primei raze.
  Pentru a gasi punctul de intersectie a unei raze cu un obiect am folosit urmatorii pasi:
- consider 2 puncte de pe raza, punctul de start si unul la o distanta de 2 de acesta
  (folosind sinusul si cosinusul unghiului fata de Ox)
- pentru fiecare obiect iau fiecare latura, care e data de 2 puncte, si calculez punctul
  de intersectie al acesteia cu raza, folosind formulele de aici
  http://mathworld.wolfram.com/Line-LineIntersection.html
- verific daca punctul de intersectie este pe directia razei, si nu cea opusa, astfel:
   * stiind punctul de start si unghiul, impart planul in 4 cadrane cu originea in
     punctul de start
   * sinusul si cosinusul unghiului vor stabili in ce cadran se duce raza fata de origine
   * verific daca punctul de intersectie se afla in acelasi cadran fata de origine
- daca directia e buna, verific daca punctul de intersectie se afla pe segmentul dat
  de cele 2 puncte si nu inafara lui. Daca se afla pe segment, atunci:
    |p1.x - p2.x| == |p1.x - i.x| + |p2.x - i.x| si analog pentru y.
  (in cod am luat o marja de eroare de 0.1 in loc de egalitate)
- daca se afla pe segment, punctul e valid si calculez distanta de la origine pana la 
  acesta
- aflu distanta minima
- calculez unghiul urmatoarei raze fata de Ox astfel (folosind functia glm::reflect):
  * consider punctul de intersectie in origine
  * vectorul incident va fi unul paralel cu raza incidenta -> translatez punctul de
    start al razei pe dreapta paralela si fata de origine
  * planul de reflexie va fi unul paralel cu latura obiectului -> calculez un punct de 
    pe dreapta paralela cu latura si care trece prin origine
  * glm::reflect va intoarce un punct de pe raza reflectata
  * calculez unghiul dintre raza reflectata si Ox insa acesta va fi in [0, pi/2)
  * pentru a calcula unghiul fata de Ox pozitiva si in sens trigonometric, aflu in ce
    cadran se afla raza fata de origine si modific unghiul dupa caz