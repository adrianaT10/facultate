﻿//-------------------------------------------------------------------------------------------------
// Descriere: fisier main
//
// Autor: student
// Data: today
//-------------------------------------------------------------------------------------------------

//incarcator de meshe
#include "lab_mesh_loader.hpp"

//geometrie: drawSolidCube, drawWireTeapot...
#include "lab_geometry.hpp"

//incarcator de shadere
#include "lab_shader_loader.hpp"

//interfata cu glut, ne ofera fereastra, input, context opengl
#include "lab_glut.hpp"

#include "lab_camera.hpp"

//time
#include <ctime>


#define ROTATION_PACE 2
#define MOVE_PACE 1

class Laborator : public lab::glut::WindowListener{

//variabile
private:
	glm::mat4 model_matrix, view_matrix, projection_matrix;										//matrici 4x4 pt modelare vizualizare proiectie
	unsigned int gl_program_shader_gouraud;														//id obiect shader gouraud

	unsigned int mesh_vbo_model, mesh_ibo_model, mesh_vao_model, mesh_num_indices_model;		//containere opengl pentru vertecsi, indecsi si stare pentru modelul incarcat

	unsigned int mesh_vbo_sphere, mesh_ibo_sphere, mesh_vao_sphere, mesh_num_indices_sphere;	//containere opengl pentru vertecsi, indecsi si stare pentru sfera ce va fi pusa la pozitia luminii

	unsigned int mesh_vbo_ground, mesh_ibo_ground, mesh_vao_ground, mesh_num_indices_ground;	//containere opengl pentru vertecsi, indecsi si stare pentru sol

	unsigned int mesh_vbo_net, mesh_ibo_net, mesh_vao_net, mesh_num_indices_net;

	glm::vec3 light_position;
	
	unsigned int material_shininess;
	float material_kd;
	float material_ks;

	bool isWater;
	bool gerstner;

	//Unda 1
	float amplitude1, freq1, phase1, q1;
	glm::vec2 direction1;

	//Unda 2
	float amplitude2, freq2, phase2, q2;
	glm::vec2 direction2;

	//Unda 3
	float amplitude3, freq3, phase3, q3;
	glm::vec2 centru;

	glm::vec3 camera_up;
	glm::vec3 camera_forward;
	glm::vec3 eye_position, camera_centre;

	lab::Camera camera;

	float time;

//metode
public:
	
	//constructor .. e apelat cand e instantiata clasa
	Laborator(){
		//setari pentru desenare, clear color seteaza culoarea de clear pentru ecran (format R,G,B,A)
		glClearColor(0.5,0.5,0.5,1);
		glClearDepth(1);			//clear depth si depth test (nu le studiem momentan, dar avem nevoie de ele!)
		glEnable(GL_DEPTH_TEST);	//sunt folosite pentru a determina obiectele cele mai apropiate de camera (la curs: algoritmul pictorului, algoritmul zbuffer)
		
		//incarca un shader din fisiere si gaseste locatiile matricilor relativ la programul creat
		gl_program_shader_gouraud = lab::loadShader("shadere\\shader_gouraud_vertex.glsl", "shadere\\shader_gouraud_fragment.glsl");
	
		//incarca plasa
		lab::createMesh(200, 200, mesh_vao_net, mesh_vbo_net, mesh_ibo_net, mesh_num_indices_net);

		amplitude1 = 1;
		freq1 = 2 * glm::pi<float>() / 10;
		phase1 = 0.1 * freq1 ;
		direction1 = glm::normalize(glm::vec2(1, -1));
		q1 = 0.8;

		amplitude2 = 1;
		freq2 = 2 * glm::pi<float>() / 12;
		phase2 = 0.1 * freq2;
		direction2 = glm::vec2(1, 0);
		q2 = 0.5;

		amplitude3 = 0.8;
		freq3 = 2 * glm::pi<float>() / 10;
		phase3 = 0.1 * freq3;
		centru = glm::vec2(20.2, -50.5);
		q3 = 0.3;

		time = 0;

		//incarca o sfera
		lab::loadObj("resurse\\sphere.obj",mesh_vao_sphere, mesh_vbo_sphere, mesh_ibo_sphere, mesh_num_indices_sphere);	

		//lumina & material
		light_position = glm::vec3(10, 7, -25);
		material_shininess = 30;
		material_kd = 0.5;
		material_ks = 0.5;

		eye_position = glm::vec3(50, 50, 0);
		camera_centre = glm::vec3(50, 0, -50);
		camera_up = glm::normalize(glm::vec3(0, 1, -1));

		camera.set(eye_position, camera_centre, camera_up);

		
		camera_forward = glm::normalize(camera_centre - eye_position);
		//matrici de modelare si vizualizare
		model_matrix = glm::mat4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
		view_matrix = camera.getViewMatrix();

		isWater = false;
		gerstner = false;

		//desenare wireframe
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	//destructor .. e apelat cand e distrusa clasa
	~Laborator(){
		//distruge shader
		glDeleteProgram(gl_program_shader_gouraud);

		//distruge mesh incarcat
		glDeleteBuffers(1,&mesh_vbo_model);
		glDeleteBuffers(1,&mesh_ibo_model);
		glDeleteVertexArrays(1,&mesh_vao_model);

		//distruge sfera
		glDeleteBuffers(1,&mesh_vbo_sphere);
		glDeleteBuffers(1,&mesh_ibo_sphere);
		glDeleteVertexArrays(1,&mesh_vao_sphere);

		//distruge solul
		glDeleteBuffers(1,&mesh_vbo_ground);
		glDeleteBuffers(1,&mesh_ibo_ground);
		glDeleteVertexArrays(1,&mesh_vao_ground);
	}


	//--------------------------------------------------------------------------------------------
	//functii de cadru ---------------------------------------------------------------------------

	//functie chemata inainte de a incepe cadrul de desenare, o folosim ca sa updatam situatia scenei ( modelam/simulam scena)
	void notifyBeginFrame(){
		view_matrix = camera.getViewMatrix();
	}
	//functia de afisare (lucram cu banda grafica)
	void notifyDisplayFrame(){
		//bufferele din framebuffer sunt aduse la valorile initiale (setate de clear color si cleardepth)
		//adica se sterge ecranul si se pune culoare (si alte propietati) initiala
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//foloseste shaderul
		glUseProgram(gl_program_shader_gouraud);
				
		//trimite variabile uniforme la shader
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_gouraud, "model_matrix"),1,false,glm::value_ptr(model_matrix));
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_gouraud, "view_matrix"),1,false,glm::value_ptr(view_matrix));
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_gouraud, "projection_matrix"),1,false,glm::value_ptr(projection_matrix));
		glUniform3f(glGetUniformLocation(gl_program_shader_gouraud, "light_position"),light_position.x, light_position.y, light_position.z);
		glUniform3f(glGetUniformLocation(gl_program_shader_gouraud, "eye_position"),eye_position.x, eye_position.y, eye_position.z);
		glUniform1i(glGetUniformLocation(gl_program_shader_gouraud, "material_shininess"),material_shininess);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "material_kd"),material_kd);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "material_ks"),material_ks);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "time"), time);
		glUniform1i(glGetUniformLocation(gl_program_shader_gouraud, "gerstner"), gerstner);

		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "ampl1"), amplitude1);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "w1"), freq1);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "phi1"), phase1);
		glUniform2f(glGetUniformLocation(gl_program_shader_gouraud, "dir1"), direction1.x, direction1.y);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "Q1"), q1);
		

		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "ampl2"), amplitude2);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "w2"), freq2);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "phi2"), phase2);
		glUniform2f(glGetUniformLocation(gl_program_shader_gouraud, "dir2"), direction2.x, direction2.y);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "Q2"), q2);

		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "ampl3"), amplitude3);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "w3"), freq3);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "phi3"), phase3);
		glUniform2f(glGetUniformLocation(gl_program_shader_gouraud, "C"), centru.x, centru.y);
		glUniform1f(glGetUniformLocation(gl_program_shader_gouraud, "Q3"), q3);
				
		isWater = true;
		glUniform1i(glGetUniformLocation(gl_program_shader_gouraud, "isWater"), isWater);
		glUniform3f(glGetUniformLocation(gl_program_shader_gouraud, "color"), 0.137255, 0.137255, 0.556863);

		glBindVertexArray(mesh_vao_net);
		glDrawElements(GL_TRIANGLES, mesh_num_indices_net, GL_UNSIGNED_INT, 0);



		//pune o sfera la pozitia luminii
		glm::mat4 matrice_translatie = glm::translate(model_matrix, glm::vec3(light_position.x,light_position.y,light_position.z));
		glm::mat4 matrice_scalare = glm::scale(model_matrix, glm::vec3(0.1,0.1,0.1));
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_gouraud, "model_matrix"),1,false,glm::value_ptr(matrice_translatie * matrice_scalare));
		isWater = false;
		glUniform1i(glGetUniformLocation(gl_program_shader_gouraud, "isWater"), isWater);
		glUniform3f(glGetUniformLocation(gl_program_shader_gouraud, "color"), 0, 1, 1);

		glBindVertexArray(mesh_vao_sphere);
		glDrawElements(GL_TRIANGLES, mesh_num_indices_sphere, GL_UNSIGNED_INT, 0);

	
		time += 1;
	}
	//functie chemata dupa ce am terminat cadrul de desenare (poate fi folosita pt modelare/simulare)
	void notifyEndFrame(){}
	//functei care e chemata cand se schimba dimensiunea ferestrei initiale
	void notifyReshape(int width, int height, int previos_width, int previous_height){
		//reshape
		if(height==0) height=1;
		glViewport(0,0,width,height);
		projection_matrix = glm::perspective(90.0f, (float)width/(float)height,0.1f, 10000.0f);
	}


	//--------------------------------------------------------------------------------------------
	//functii de input output --------------------------------------------------------------------
	
	//tasta apasata
	void notifyKeyPressed(unsigned char key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == 27) lab::glut::close();	//ESC inchide glut si 
		if(key_pressed == 32) {	//SPACE
			//reincarca shader
			glDeleteProgram(gl_program_shader_gouraud);
			gl_program_shader_gouraud = lab::loadShader("shadere\\shader_gouraud_vertex.glsl", "shadere\\shader_gouraud_fragment.glsl");
		}
		if (key_pressed == '1'){
			gerstner = false;
		}
		if (key_pressed == '2'){
			gerstner = true;
		}
		if(key_pressed == 'm'){
			static bool wire =true;
			wire=!wire;
			glPolygonMode(GL_FRONT_AND_BACK, (wire?GL_LINE:GL_FILL));
		}
		if (key_pressed == 'h') {
			light_position.x -= 1;
		}
		if (key_pressed == 'k') {
			light_position.x += 1;
		}
		if (key_pressed == 'u') {
			light_position.z -= 1;
		}
		if (key_pressed == 'j') {
			light_position.z += 1;
		}
		if (key_pressed == 'y') {
			light_position.y += 1;
		}
		if (key_pressed == 'i') {
			light_position.y -= 1;
		}
		if (key_pressed == 'a') {
			translateCameraRight(-1);
		}
		if (key_pressed == 'd') {
			translateCameraRight(1);
		}
		if (key_pressed == 'w') {
			translateCameraForward(1);
		}
		if (key_pressed == 's') {
			translateCameraForward(-1);
		}
		if (key_pressed == 'q') {
			translateCameraUpward(1);
		}
		if (key_pressed == 'e') {
			translateCameraUpward(-1);
		}


	}

	void translateCameraForward(float distance)
	{
		//eye_position += glm::normalize(camera_forward) * distance;
		camera.translateForward(distance);
		eye_position = camera.getPosition();
	}

	void translateCameraUpward(float distance)
	{
		//eye_position += glm::normalize(camera_up) * distance;
		camera.translateUpword(distance);
		eye_position = camera.getPosition();
	}

	void translateCameraRight(float distance)
	{
		//eye_position += glm::normalize(camera_right) * distance;
		camera.translateRight(distance);
		eye_position = camera.getPosition();
	}
	void rotateCameraOx(float angle) {
		camera.rotateFPS_OX(angle);
		eye_position = camera.getPosition();
	}
	void rotateCameraOy(float angle) {
		camera.rotateFPS_OY(angle);
		eye_position = camera.getPosition();
	}
	void rotateCameraOz(float angle) {
		camera.rotateFPS_OZ(angle);
		eye_position = camera.getPosition();
	}
	//tasta ridicata
	void notifyKeyReleased(unsigned char key_released, int mouse_x, int mouse_y){	}
	//tasta speciala (up/down/F1/F2..) apasata
	void notifySpecialKeyPressed(int key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == GLUT_KEY_F1) lab::glut::enterFullscreen();
		if(key_pressed == GLUT_KEY_F2) lab::glut::exitFullscreen();
		if (key_pressed == GLUT_KEY_UP) rotateCameraOx(2);
		if (key_pressed == GLUT_KEY_DOWN) rotateCameraOx(-2);
		if (key_pressed == GLUT_KEY_LEFT) rotateCameraOy(2);
		if (key_pressed == GLUT_KEY_RIGHT) rotateCameraOy(-2);
	}
	//tasta speciala ridicata
	void notifySpecialKeyReleased(int key_released, int mouse_x, int mouse_y){}
	//drag cu mouse-ul
	void notifyMouseDrag(int mouse_x, int mouse_y){ }
	//am miscat mouseul (fara sa apas vreun buton)
	void notifyMouseMove(int mouse_x, int mouse_y){ }
	//am apasat pe un boton
	void notifyMouseClick(int button, int state, int mouse_x, int mouse_y){ }
	//scroll cu mouse-ul
	void notifyMouseScroll(int wheel, int direction, int mouse_x, int mouse_y){ std::cout<<"Mouse scroll"<<std::endl;}

};

int main(){
	//initializeaza GLUT (fereastra + input + context OpenGL)
	lab::glut::WindowInfo window(std::string("EGC - lab 6 - iluminare Gouraud"),800,600,100,100,true);
	lab::glut::ContextInfo context(3,3,false);
	lab::glut::FramebufferInfo framebuffer(true,true,true,true);
	lab::glut::init(window,context, framebuffer);

	//initializeaza GLEW (ne incarca functiile openGL, altfel ar trebui sa facem asta manual!)
	glewExperimental = true;
	glewInit();
	std::cout<<"GLEW:initializare"<<std::endl;

	//creem clasa noastra si o punem sa asculte evenimentele de la GLUT
	//DUPA GLEW!!! ca sa avem functiile de OpenGL incarcate inainte sa ii fie apelat constructorul (care creeaza obiecte OpenGL)
	Laborator mylab;
	lab::glut::setListener(&mylab);

	//taste
	std::cout<<"Taste:"<<std::endl<<"\tESC ... iesire"<<std::endl<<"\tSPACE ... reincarca shadere"<<std::endl<<"\tw ... toggle wireframe"<<std::endl;

	//run
	lab::glut::run();

	return 0;
}