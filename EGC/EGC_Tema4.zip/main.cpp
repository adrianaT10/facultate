﻿//-------------------------------------------------------------------------------------------------
// Descriere: fisier main
//
// Autor: student
// Data: today
//-------------------------------------------------------------------------------------------------

//incarcator de meshe
#include "lab_mesh_loader.hpp"
//geometrie: drawSolidCube, drawWireTeapot...
#include "lab_geometry.hpp"
//incarcator de shadere
#include "lab_shader_loader.hpp"
//interfata cu glut, ne ofera fereastra, input, context opengl
#include "lab_glut.hpp"
//texturi
#include "lab_texture_loader.hpp"
//time
#include <ctime>

#include "lab_camera.hpp"

#define TRANSLATE_PACE 0.1f
#define SCALE_PACE 1.2f
#define LETTER_DIM 8
#define MENIU_DIM 2


class Laborator : public lab::glut::WindowListener
{
	//variabile
	private:
		glm::mat4 model_matrix_panou, model_matrix_floor, model_matrix_mesaj_panou;	//matrici modelare pentru cele 3 obiecte
		glm::mat4 model_matrix_mesaj_orig, model_matrix_meniu;
		glm::mat4 view_matrix, projection_matrix, meniu_view_matrix, meniu_projection_matrix;											//matrici 4x4 pt modelare vizualizare proiectie
		unsigned int gl_program_shader;														//id-ul de opengl al obiectului de tip program shader
		unsigned int screen_width, screen_height;

		//meshe	
		unsigned int panou_vbo, panou_ibo, panou_vao, panou_num_indices;
		unsigned int floor_vbo, floor_ibo, floor_vao, floor_num_indices;
		unsigned int mesaj_panou_vbo, mesaj_panou_ibo, mesaj_panou_vao, mesaj_panou_num_indices;
		unsigned int meniu_vbo, meniu_ibo, meniu_vao, meniu_num_indices;

		//texturi
		unsigned int panou_texture, floor_texture, mesaj_panou_texture_color, mesaj_panou_texture_alpha;


		//litere pe panou
		std::vector<lab::VertexFormat> panou_vertices;
		std::vector<unsigned int> panou_indices;
		float translated_units;

		//litere meniu
	    std::vector<lab::VertexFormat> meniu_vertices;
		std::vector<unsigned int> meniu_indices;
		bool show_menu;
		

		bool edit_active;
		float scale_factor;
		bool make_smaller, make_bigger;

		unsigned int material_shininess;
		float material_kd;
		float material_ks;
		glm::vec3 light_position;
		glm::vec3 spot_direction;


		// Camera
		lab::Camera camera;
		glm::mat4 projectionMatrix;
		float FoV;
		float zNear, zFar;
		float aspectRatio;

		// Buffer for input
		char keyState[256];
		char specialKeyState[256];

		unsigned int frameTime;
		
		unsigned int previousTime;

	//metode
	public:
	
		//constructor .. e apelat cand e instantiata clasa
		Laborator()
		{
			//setari pentru desenare, clear color seteaza culoarea de clear pentru ecran (format R,G,B,A)
			glClearColor(0,0,0,1);
			glClearDepth(1);			//clear depth si depth test (nu le studiem momentan, dar avem nevoie de ele!)
			glEnable(GL_DEPTH_TEST);	//sunt folosite pentru a determina obiectele cele mai apropiate de camera (la curs: algoritmul pictorului, algoritmul zbuffer)
		
			//incarca un shader din fisiere si gaseste locatiile matricilor relativ la programul creat
			gl_program_shader = lab::loadShader("shadere\\shader_vertex.glsl", "shadere\\shader_fragment.glsl");
		

			//panoul
			lab::createPanel(50, 20, panou_vao, panou_vbo, panou_ibo, panou_num_indices);
			model_matrix_panou = glm::translate(glm::mat4(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), glm::vec3(-20, 10, -10));
			panou_texture = lab::loadTextureBMP("resurse\\metal.bmp");
		
			//solul
			//lab::createFloor(200, 200, floor_vao, floor_vbo, floor_ibo, floor_num_indices);
			lab::createPanel(200, 200, floor_vao, floor_vbo, floor_ibo, floor_num_indices);
			float angle = 90;
			model_matrix_floor = glm::translate(glm::mat4(1), glm::vec3(-100, -10, 100));
			model_matrix_floor = glm::rotate(model_matrix_floor, -angle, glm::vec3(1, 0, 0));
			floor_texture = lab::loadTextureBMP("resurse\\caramida.bmp");

			//quad pt litere
			lab::addToPanel('a', mesaj_panou_vao, mesaj_panou_vbo, mesaj_panou_ibo, mesaj_panou_num_indices,
				             panou_vertices, panou_indices, LETTER_DIM);
			mesaj_panou_texture_color = lab::loadTextureBMP("resurse\\litere.bmp");
			mesaj_panou_texture_alpha = lab::loadTextureBMP("resurse\\litere.bmp");
			model_matrix_mesaj_orig = glm::translate(model_matrix_panou, glm::vec3(46, 0, 0.1));
			model_matrix_mesaj_panou.operator=(model_matrix_mesaj_orig);
			translated_units = 0;

			//meniul
			lab::addToPanel('M', meniu_vao, meniu_vbo, meniu_ibo, meniu_num_indices, meniu_vertices, meniu_indices, MENIU_DIM);
			lab::addToPanel('E', meniu_vao, meniu_vbo, meniu_ibo, meniu_num_indices, meniu_vertices, meniu_indices, MENIU_DIM);
			lab::addToPanel('N', meniu_vao, meniu_vbo, meniu_ibo, meniu_num_indices, meniu_vertices, meniu_indices, MENIU_DIM);
			lab::addToPanel('I', meniu_vao, meniu_vbo, meniu_ibo, meniu_num_indices, meniu_vertices, meniu_indices, MENIU_DIM);
			lab::addToPanel('U', meniu_vao, meniu_vbo, meniu_ibo, meniu_num_indices, meniu_vertices, meniu_indices, MENIU_DIM);
			model_matrix_meniu = glm::translate(glm::mat4(1), glm::vec3(-13, 9, 80));
			show_menu = false;

			//matrici de modelare si vizualizare
			view_matrix = glm::lookAt(glm::vec3(0,0,40), glm::vec3(0,0,0), glm::vec3(0,1,0));
			meniu_view_matrix = glm::lookAt(glm::vec3(0, 0, 100), glm::vec3(0, 0, 90), glm::vec3(0, 1, 0));

			// init camera
			camera.set(glm::vec3(0, 20, 50), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));
			memset(keyState, 0, 256);
			memset(specialKeyState, 0, 256);

			// Initialize default projection values
			zNear = 0.1f;
			zFar = 500.0f;
			FoV = 60.0f;
			aspectRatio = 800 / 600.0f;

			light_position = glm::vec3(0, 20, 50);
			spot_direction = glm::vec3(0, 0, 0) - light_position;
			//spot_direction = glm::vec3(1, 1, 1);
			material_shininess = 30;
			material_kd = 0.5;
			material_ks = 0.5;

			previousTime = 0;

			//desenare wireframe
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

			edit_active = false;
			scale_factor = 1;
			make_smaller = false;
			make_bigger = false;
		}

		//destructor .. e apelat cand e distrusa clasa
		~Laborator(){
			//distruge shader
			glDeleteProgram(gl_program_shader);

			//distruge obiecte
			glDeleteBuffers(1,&panou_vbo);	glDeleteBuffers(1,&panou_ibo);	glDeleteVertexArrays(1,&panou_vao);		glDeleteTextures(1, &panou_texture);
			glDeleteBuffers(1,&floor_vbo);	glDeleteBuffers(1,&floor_ibo);	glDeleteVertexArrays(1,&floor_vao);		glDeleteTextures(1, &floor_texture);	
		}

		void computePerspectiveProjection()
		{
			projectionMatrix = glm::perspective(FoV, aspectRatio, zNear, zFar);
		}

		// Called every frame to draw
		void treatInput()
		{
			unsigned int time = glutGet(GLUT_ELAPSED_TIME);
			frameTime = time - previousTime;
			previousTime = time;

			float moveSpeed = frameTime / 20.0f;
			float rotateSpeed = frameTime / 20.0f;

			// Camera Translation
			if (keyState['w']) { 
				camera.translateForward(moveSpeed); 
			}
			if (keyState['a']) { camera.translateRight(-moveSpeed); }
			if (keyState['s']) { camera.translateForward(-moveSpeed); }
			if (keyState['d']) { camera.translateRight(moveSpeed); }
			if (keyState['e']) { camera.translateUpword(moveSpeed); }
			if (keyState['q']) { camera.translateUpword(-moveSpeed); }

			// Camera Rotate FPS
			if (specialKeyState[GLUT_KEY_LEFT]) { 
				camera.rotateFPS_OY(rotateSpeed); }
			if (specialKeyState[GLUT_KEY_RIGHT]) { camera.rotateFPS_OY(-rotateSpeed); }

			if (specialKeyState[GLUT_KEY_UP]) { camera.rotateFPS_OX(rotateSpeed); }
			if (specialKeyState[GLUT_KEY_DOWN]) { camera.rotateFPS_OX(-rotateSpeed); }
		}


		//--------------------------------------------------------------------------------------------
		//functii de cadru ---------------------------------------------------------------------------

		//functie chemata inainte de a incepe cadrul de desenare, o folosim ca sa updatam situatia scenei ( modelam/simulam scena)
		void notifyBeginFrame(){
			int distance_unit = panou_vertices[1].position_x - panou_vertices[0].position_x;
			int nr_letters = panou_vertices.size() / 4;
			float total_length = distance_unit * nr_letters * scale_factor + 50;

			if (fabs(translated_units - total_length) < 0.09) {
				translated_units = 0;
				model_matrix_mesaj_panou = model_matrix_mesaj_orig;
			}
			translated_units += TRANSLATE_PACE;
			treatInput();


			if (make_bigger) {
				model_matrix_mesaj_panou = glm::scale(model_matrix_mesaj_panou, glm::vec3(SCALE_PACE, SCALE_PACE, 0));
				model_matrix_mesaj_orig = glm::scale(model_matrix_mesaj_orig, glm::vec3(SCALE_PACE, SCALE_PACE, 0));
				make_bigger = false;
			}
			else if (make_smaller) {
				model_matrix_mesaj_panou = glm::scale(model_matrix_mesaj_panou, glm::vec3(1/SCALE_PACE, 1/SCALE_PACE, 0));
				model_matrix_mesaj_orig = glm::scale(model_matrix_mesaj_orig, glm::vec3(1/SCALE_PACE, 1/SCALE_PACE, 0));
				make_smaller = false;
			}
			model_matrix_mesaj_panou = glm::translate(model_matrix_mesaj_panou, glm::vec3(-TRANSLATE_PACE, 0, 0));

			light_position = camera.getPosition();
			spot_direction = camera.getForward();
			
		}
		//functia de afisare (lucram cu banda grafica)
		void notifyDisplayFrame()
		{
			//pe tot ecranul
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
			//foloseste shaderul
			glUseProgram(gl_program_shader);

			glUniform1i(glGetUniformLocation(gl_program_shader, "is_mesaj_panou"), 0);
				
			//trimite variabile uniforme la shader
			glUniformMatrix4fv(glGetUniformLocation(gl_program_shader,"view_matrix"),1,false,glm::value_ptr(camera.getViewMatrix()));
			glUniformMatrix4fv(glGetUniformLocation(gl_program_shader,"projection_matrix"),1,false,glm::value_ptr(projection_matrix));
			glUniform3f(glGetUniformLocation(gl_program_shader, "light_position"), light_position.x, light_position.y, light_position.z);
			glUniform3f(glGetUniformLocation(gl_program_shader, "light_direction"), spot_direction.x, spot_direction.y, spot_direction.z);
			glUniform1i(glGetUniformLocation(gl_program_shader, "material_shininess"), material_shininess);
			glUniform1f(glGetUniformLocation(gl_program_shader, "material_kd"), material_kd);
			glUniform1f(glGetUniformLocation(gl_program_shader, "material_ks"), material_ks);

			glUniform1i(glGetUniformLocation(gl_program_shader, "has_alpha"), 0);
			glUniform3f(glGetUniformLocation(gl_program_shader, "color"), 1, 1, 1);

			//panoul
			glUniformMatrix4fv(glGetUniformLocation(gl_program_shader, "model_matrix"), 1, false,glm::value_ptr(model_matrix_panou));
			glBindVertexArray(panou_vao);
			glActiveTexture(GL_TEXTURE0 + 1);
			glBindTexture(GL_TEXTURE_2D, panou_texture);
			glUniform1i(glGetUniformLocation(gl_program_shader, "textura1"), 1);
			glDrawElements(GL_TRIANGLES, panou_num_indices, GL_UNSIGNED_INT, 0);

			//solul
			glUniformMatrix4fv(glGetUniformLocation(gl_program_shader, "model_matrix"), 1, false, glm::value_ptr(model_matrix_floor));
			glBindVertexArray(floor_vao);
			glActiveTexture(GL_TEXTURE0 + 2);
			glBindTexture(GL_TEXTURE_2D, floor_texture);
			glUniform1i(glGetUniformLocation(gl_program_shader, "textura1"), 2);
			glDrawElements(GL_TRIANGLES, floor_num_indices, GL_UNSIGNED_INT, 0);

			//mesaj panou
			glUniformMatrix4fv(glGetUniformLocation(gl_program_shader, "model_matrix"), 1, false, glm::value_ptr(model_matrix_mesaj_panou));
			glUniform1i(glGetUniformLocation(gl_program_shader, "has_alpha"), 1);
			glUniform1i(glGetUniformLocation(gl_program_shader, "is_mesaj_panou"), 1);
			glUniform3f(glGetUniformLocation(gl_program_shader, "color"), 1, 1, 0);
			glBindVertexArray(mesaj_panou_vao);
			glActiveTexture(GL_TEXTURE0 + 3); // pt alpha
			glBindTexture(GL_TEXTURE_2D, mesaj_panou_texture_alpha);
			glUniform1i(glGetUniformLocation(gl_program_shader, "textura2"), 3); // trimitem la shader unitatea de text
			glActiveTexture(GL_TEXTURE0 + 4);//pt acolor
			glBindTexture(GL_TEXTURE_2D, mesaj_panou_texture_color);
			glUniform1i(glGetUniformLocation(gl_program_shader, "textura1"), 4); // trimitem la shader unitatea de text

			glDrawElements(GL_TRIANGLES, mesaj_panou_num_indices, GL_UNSIGNED_INT, 0);

			//meniu
			
			if (show_menu) {
				glUniform1i(glGetUniformLocation(gl_program_shader, "is_mesaj_panou"), 0);
				glUniformMatrix4fv(glGetUniformLocation(gl_program_shader, "view_matrix"), 1, false, glm::value_ptr(meniu_view_matrix));
				glUniformMatrix4fv(glGetUniformLocation(gl_program_shader, "model_matrix"), 1, false, glm::value_ptr(model_matrix_meniu));
				glUniform1i(glGetUniformLocation(gl_program_shader, "has_alpha"), 1);
				glUniform3f(glGetUniformLocation(gl_program_shader, "color"), 1, 0, 0);
				glBindVertexArray(meniu_vao);
				glActiveTexture(GL_TEXTURE0 + 5); // pt alpha
				glBindTexture(GL_TEXTURE_2D, mesaj_panou_texture_alpha);
				glUniform1i(glGetUniformLocation(gl_program_shader, "textura2"), 5); // trimitem la shader unitatea de text
				glActiveTexture(GL_TEXTURE0 + 6);//pt acolor
				glBindTexture(GL_TEXTURE_2D, mesaj_panou_texture_color);
				glUniform1i(glGetUniformLocation(gl_program_shader, "textura1"), 6); // trimitem la shader unitatea de text

				glDrawElements(GL_TRIANGLES, meniu_num_indices, GL_UNSIGNED_INT, 0);
			}
			
		}

		//functie chemata dupa ce am terminat cadrul de desenare (poate fi folosita pt modelare/simulare)
		void notifyEndFrame(){}

		//functei care e chemata cand se schimba dimensiunea ferestrei initiale
		void notifyReshape(int width, int height, int previos_width, int previous_height){
			//reshape
			if(height==0) height=1;
			float aspect = (float)width / (float)height;
			projection_matrix = glm::perspective(75.0f, aspect,0.1f, 10000.0f);
		}


		//--------------------------------------------------------------------------------------------
		//functii de input output --------------------------------------------------------------------
	
		//tasta apasata
		void notifyKeyPressed(unsigned char key_pressed, int mouse_x, int mouse_y)
		{
			if (!edit_active) {
				keyState[key_pressed] = 1;
				if (key_pressed == 32) {
					//SPACE reincarca shaderul si recalculeaza locatiile (offseti/pointeri)
					glDeleteProgram(gl_program_shader);
					gl_program_shader = lab::loadShader("shadere\\shader_vertex.glsl", "shadere\\shader_fragment.glsl");
				}
				
				if (key_pressed == 'm') { // mareste fontul
					scale_factor *= SCALE_PACE;
					make_bigger = true;
				}
				if (key_pressed == 'n') { //micsoreaza fontul
					scale_factor /= SCALE_PACE;
					make_smaller = true;
				}
				if (key_pressed == 'y') {
					show_menu = !show_menu;
				}
			}
			else {
				//litere_panou.push_back(key_pressed);
				lab::addToPanel(key_pressed, mesaj_panou_vao, mesaj_panou_vbo, mesaj_panou_ibo, mesaj_panou_num_indices,
					panou_vertices, panou_indices, LETTER_DIM);
			}
			if(key_pressed == 27) lab::glut::close();	//ESC inchide glut

		}
		//tasta ridicata
		void notifyKeyReleased(unsigned char key_released, int mouse_x, int mouse_y){
			keyState[key_released] = 0;
		}

		//tasta speciala (up/down/F1/F2..) apasata
		void notifySpecialKeyPressed(int key_pressed, int mouse_x, int mouse_y){
			specialKeyState[key_pressed] = 1;
			if(key_pressed == GLUT_KEY_F1) lab::glut::enterFullscreen();
			if(key_pressed == GLUT_KEY_F2) lab::glut::exitFullscreen();
			if (key_pressed == GLUT_KEY_F8) edit_active = !edit_active;
		}
		//tasta speciala ridicata
		void notifySpecialKeyReleased(int key_released, int mouse_x, int mouse_y){
			specialKeyState[key_released] = 0;
		}
		//drag cu mouse-ul
		void notifyMouseDrag(int mouse_x, int mouse_y){ }
		//am miscat mouseul (fara sa apas vreun buton)
		void notifyMouseMove(int mouse_x, int mouse_y){ }
		//am apasat pe un boton
		void notifyMouseClick(int button, int state, int mouse_x, int mouse_y){ }
		//scroll cu mouse-ul
		void notifyMouseScroll(int wheel, int direction, int mouse_x, int mouse_y){ }

};

int main()
{
	//initializeaza GLUT (fereastra + input + context OpenGL)
	lab::glut::WindowInfo window(std::string("lab EGC 8 - texturi"),800,600,100,100,true);
	lab::glut::ContextInfo context(3,3,false);
	lab::glut::FramebufferInfo framebuffer(true,true,true,true);
	lab::glut::init(window,context, framebuffer);

	//initializeaza GLEW (ne incarca functiile openGL, altfel ar trebui sa facem asta manual!)
	glewExperimental = true;
	glewInit();
	std::cout<<"GLEW:initializare"<<std::endl;

	//creem clasa noastra si o punem sa asculte evenimentele de la GLUT
	//DUPA GLEW!!! ca sa avem functiile de OpenGL incarcate inainte sa ii fie apelat constructorul (care creeaza obiecte OpenGL)
	Laborator mylab;
	lab::glut::setListener(&mylab);

	//taste
	std::cout<<"Taste:"<<std::endl<<"\tESC ... iesire"<<std::endl<<"\tSPACE ... reincarca shadere"<<std::endl<<"\tw ... toggle wireframe"<<std::endl;

	//run
	lab::glut::run();

	return 0;
}