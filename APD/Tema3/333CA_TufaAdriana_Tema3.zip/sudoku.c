#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int NP; //nr de procese
int MAX_SOL = 100;
int start_l = -1; // linia de inceput a patratului meu
int start_col = -1; //coloana de inceput a patratului meu
int ***results; //rezultatele mele partiale
int **sudoku; //matricea citita din fisier
//solutii partiale combinate, nr de solutii curente, si dimensiunea vectorului
int ***combined_res, no_cr = 0, max_cr = 0;
char **combined_nodes; // nodurile care au contribuit la fiecare solutie in parte
char *output_file; //fisierul in care se scriu rezultatele

void assemble_partial_sol(int dim, int **sol, int l, int res[l][l]);
void combine(int l, int** sol_p, int sol_c[l][l], int res[l][l]);
void assemble_partial_sol2(int dim, int sol[dim][dim], int l, int res[l][l]);

/* Afiseaza matricea de adiacenta */
void print_top(int top[NP][NP], int rank) {
  int i, j;

  printf("P%d - Topologia este: \n", rank);
    for(i = 0; i < NP; i++) {
      for(j = 0; j < NP; j++) {
        printf("%d ", top[i][j]);
      }
      printf("\n");
    }
}

void print_mat(int latura, int m[latura][latura]) {
  int i, j;

  for(i = 0; i < latura; i++) {
    for(j = 0; j < latura; j++) {
      printf("%d ", m[i][j]);
    }
    printf("\n");
  }
}

/* Realoca mai multa memorie pentru un tablou tridimensional
   crt - indicele pana la care e completat tabloul
   maxv - dimensiunea maxima curenta */
int *** resize(int ***v, int crt, int *maxv, int latura) {
  int ***new_v;
  int i, j, t;
  int max = 2 * (*maxv);

  new_v = (int ***)malloc(max * sizeof(int **));
  for(i = 0; i < max; i++) {
    new_v[i] = (int **)malloc(latura * sizeof(int *));
    for(j = 0; j < latura; j++) {
      new_v[i][j] = (int *)malloc(latura * sizeof(int));
      }
  }

  for(t = 0; t < crt; t++) {
    for(i = 0; i < latura; i++) {
      for(j = 0; j < latura; j++) {
        new_v[t][i][j] = v[t][i][j];
      }
    }
  }

  for(i = 0; i < (*maxv); i++) {
    for(j = 0; j < latura; j++) {
      free(v[i][j]);
    }
    free(v[i]);
  }
  free(v);

  (*maxv) = max;

  return new_v;
}

/* Realoca memorie pentru tabloul combined_nodes */
char ** resize_combined(int crt, int old_dim, int new_dim) {
  char **new_v;
  int i, j;

  new_v = (char **)malloc(new_dim * sizeof(char *));

  for(i = 0; i < crt; i++) {
    new_v[i] = (char *)malloc(NP * sizeof(char));
    for(j = 0; j < NP; j++) {
      new_v[i][j] = combined_nodes[i][j];
    }
  }

  for(i = crt; i < new_dim; i++) {
    new_v[i] = (char *)calloc(NP, sizeof(char));
  }

  for(i = 0; i < old_dim; i++) {
    free(combined_nodes[i]);
  }
  free(combined_nodes);

  return new_v;
}

/* Combina topologia curenta cu o topologie primita */
void update(int top[NP][NP], int new_top[NP][NP], int parinte) {
  int i, j;
  for(i = 0; i < NP; i++){
   if(i != parinte)
     for(j = 0; j < NP; j++) {
       if(new_top[i][j] == 1)
         top[i][j] = new_top[i][j];
     }
  }
}

/* Updateaza tabela de rutare */
void update_tabela(int top_recv[NP][NP], int tabela[NP], int nod) {
  int i, j;

  for(i = 0; i < NP; i++) {
    for(j = 0; j < NP; j++) {
      if(top_recv[i][j] == 1) {
        tabela[i] = nod;
      }
    }
  }
}

/* Afiseaza tabela de rutare */
void print_tabela(int tabela[NP], int nod) {
  int i;
  printf("Tabela de rutare pentru %d:\nSursa - Destinatie\n", nod);
  for(i = 0; i < NP; i++) {
    printf("%d - %d\n", i, tabela[i]);
  }
}

/* Citeste vecinii din fisierul de intrare; returneaza nr de copii */
int read_neighbours(char *file, int top[NP][NP], int rank) {
  FILE *fin;
  int vecin, nr_vecini = -1;
  char *line = NULL;
  size_t num = 0;
  int i = 0;

  fin = fopen(file, "r");
  if(fin == NULL) {
    printf("FISIER NUL\n");
  }

  //citeste linia corespunzatoare procesului
  while(i <= rank && getline(&line, &num, fin) != -1 ) {
    i++;
  }
  fclose(fin);

  //line are forma: sursa - vec1 vec2 .. vecn
  char *vecin_char = strtok(line, "-");
  while(vecin_char != NULL) {
    vecin_char = strtok(NULL, " -\\n");
    if(vecin_char != NULL) {
      vecin = atoi(vecin_char);
      top[rank][vecin] = 1;
      nr_vecini ++;
    }
  }
  
  return nr_vecini;
}

/* Citeste matricea de sudoku din fisier si o returneaza */
int** read_sudoku(char *file, int latura){
  FILE *fin;
  char *aux, auxx;
  int numar, i = 0, j = 0;
  size_t len = 0;
  char *line = NULL;
  int **sudoku;
  sudoku = (int **)malloc(latura * sizeof(int *));

  fin = fopen(file, "r");
  if(fin == NULL) {
    printf("FISIER NUL\n");
  }

  fscanf(fin, "%c\n", &auxx);

  while (getline(&line, &len, fin) != -1 && i < latura) {
    sudoku[i] = (int *)malloc(latura * sizeof(int));
    aux = strtok(line, " ");
    numar = atoi(aux);
    sudoku[i][0] = numar;
    j = 1;
    while( aux != NULL && j < latura) {
      aux = strtok(NULL, " ");
      if(aux != NULL) {
        numar = atoi(aux);
        sudoku[i][j] = numar;
        j++;
      }
    }

    i++;
  }

  return sudoku;
}

/* Scrie solutia finala in fisier */
void write_solution(int latura, int sol[latura][latura]) {
  FILE *fout = fopen(output_file, "w");
  int i, j, dim;

  if(fout == NULL) {
    printf("FISIER NUL\n");
    return;
  }

  dim = sqrt(latura);
  fprintf(fout, "%d\n", dim);

  for(i = 0; i < latura; i++) {
    for(j = 0; j < latura - 1; j++) {
      fprintf(fout, "%d ", sol[i][j]);
    }
    fprintf(fout, "%d", sol[i][latura - 1]);
    fprintf(fout, "\n");
  }

  fclose(fout);
}

/* Selecteaza urmatorul patrat (dim x dim) disponibil din m si marcheaza pozitiile ocupate */
int** choose_square(int latura, int m[latura][latura], int dim) {
  int i, j, k, t, ii, jj;
  int **square = (int **)malloc(dim * sizeof(int *));

  for(i = 0; i < latura; i++) {
    for(j = 0; j < latura; j++) {
      if(m[i][j] != -1) {
        ii = i;
        jj = j;
        break;
      }
    }
    if(j != latura) break;
  }
 
  if(start_l == -1) {
    start_l = ii;
    start_col = jj;
  }

  for(k = 0; k < dim; k++, ii++) {
    square[k] = (int *)malloc(dim * sizeof(int));
    j = jj;
    for(t = 0; t < dim; t++, j++) {
      square[k][t] = m[ii][j];
      m[ii][j] = -1;
    }
  }

  return square;
}

/* Returneaza numarul de copii de pe un branch. */
int count_nodes_on_branch(int top[NP][NP]) {
  int i, j, nr = 0;
  
  // numarul de copii = nr de linii completate
  for(i = 0; i < NP; i++) {
    for(j = 0; j< NP; j++) {
      if(top[i][j] == 1) {
        nr ++;
        break;
      }
    }
  }

  return nr;
}

/* Trimite copiilor matricea sudoku cu pozitiile libere marcate */
void send_matrix_to_children(int top[NP][NP], int rank, int parinte,int child_info[NP], 
                            int latura, int matrix[latura][latura], int dim_probl) {
  int i, j;
  int len = latura * latura;
  MPI_Comm comm = MPI_COMM_WORLD;
  int sudoku_send[latura][latura];
  for(i = 0; i < latura; i++) {
    for(j = 0; j < latura; j++) {
      sudoku_send[i][j] = sudoku[i][j];
    }
  }

  for(i = 0; i < NP; i++) {
      if(child_info[i] != 0 && i != parinte) {
        MPI_Send(sudoku_send, len, MPI_INT, i, 1, comm);
        MPI_Send(matrix, len, MPI_INT, i, 1, comm);
        // marcheaza pozitiile ce vor fi alocate de toate nodurile de pe ramura i
        int count = child_info[i];
        while(count > 0) {
          choose_square(latura, matrix, dim_probl);
          count --;
        }
      }
    }
}

/* Verifica daca pozitia (ii, jj) e completata corect */
int check(int dim, int sol[dim][dim], int ii, int jj) {
  int i, j;

  //verifica duplicate pentru interiorul patratului
  for(i = 0; i < dim; i++) {
    for(j = 0; j < dim; j++) {
      if(sol[i][j] != 0 && (i != ii || j != jj)) {
        if(sol[i][j] == sol[ii][jj]) {
          return 0;
        }
      }
    }
  }

  //verificare pe linie si coloana
  int lat = NP;
  int aux[NP][NP], res[NP][NP];
  assemble_partial_sol2(dim, sol, NP, aux);
  combine(NP, sudoku, aux, res);
  ii += start_l;
  jj += start_col;
  for(i = 0; i < lat; i++) {
    if(i != jj && res[ii][i] == res[ii][jj]) return 0;
    if(i != ii && res[i][jj] == res[ii][jj]) return 0;
  }

  return 1; // OK
}

/* Backtracking recursiv */
void back(int dim, int crt[dim][dim], int ii, int jj) {
  int i, j, k;

  //daca s-a ajuns la o solutie finala
  if(ii == dim && jj == 0 && check(dim, crt, dim-1, dim-1)) {
    for(k = 0; k < MAX_SOL; k++) {
      if(results[k][0][0] == -1) break;
    }
    //daca nu este de ajuns spatiu in results, redimensioneaza
    if(k == MAX_SOL) {
      results = resize(results, k, &MAX_SOL, dim);
      for(i = k; i < MAX_SOL; i++)
        results[i][0][0] = -1;
    }
    //adauga solutia
    for(i = 0; i < dim; i++) {
      for(j = 0; j < dim; j++) {
        results[k][i][j] = crt[i][j];
      }
    }
    return;
  }

  //daca e pozitie libera
  if(crt[ii][jj] == 0) {
    for(k = 1; k <= dim * dim; k++) {
      crt[ii][jj] = k;
      if(check(dim, crt, ii, jj) == 1) {
        if((jj + 1) % dim == 0) {
          back(dim, crt, ii + 1, 0);
        } else {
          back(dim, crt, ii, jj + 1);
        }
      }
      crt[ii][jj] = 0;
    }
  } //daca e pozitie deja completata
  else {
    if((jj + 1) % dim == 0) {
      back(dim, crt, ii + 1, 0);
    } else {
      back(dim, crt, ii, jj + 1);
    }
  }
}

/* Calculeaza si intoarce numarul de solutii partiale */
int compute_my_solutions(int dim_probl, int **initial_square) {
  int i, j;
  int count = 0;
  int current_sol[dim_probl][dim_probl];

  for(i = 0; i < MAX_SOL; i++) {
    results[i][0][0] = -1; // rezultat necompletat
  }

  for(i = 0; i < dim_probl; i++) {
    for(j = 0; j < dim_probl; j++) {
      current_sol[i][j] = initial_square[i][j];
    }
  }

  back(dim_probl, current_sol, 0, 0);

  for(i = 0; i < MAX_SOL; i++) {
    if(results[i][0][0] != -1) count++;
    else break;
  }

  return count;
}

/* Pune un rezultat partial intr-o matrice de sudoku mare 
   - dim - dimensiunea patratului mic
   - sol - rezulatul partial
   - l - latura patratului mare
   - res - matricea rezultata */
void assemble_partial_sol(int dim, int **sol, int l, int res[l][l]) {
  int i, j, k, t;
  int ii = start_l;
  int jj = start_col;

  for(i = 0; i < l; i++) {
    for(j = 0; j < l; j++) {
      res[i][j] = 0;
    }
  }

  for(i = ii, k = 0; i < ii+dim; i++, k++) {
    for(j = jj, t = 0; j < jj + dim; j++, t++) {
      res[i][j] = sol[k][t];
    }
  }
}

void assemble_partial_sol2(int dim, int sol[dim][dim], int l, int res[l][l]) {
  int i, j, k, t;
  int ii = start_l;
  int jj = start_col;

  for(i = 0; i < l; i++) {
    for(j = 0; j < l; j++) {
      res[i][j] = 0;
    }
  }

  for(i = ii, k = 0; i < ii+dim; i++, k++) {
    for(j = jj, t = 0; j < jj + dim; j++, t++) {
      res[i][j] = sol[k][t];
    }
  }
}

/* Combina sol_p cu sol_c */
void combine(int l, int** sol_p, int sol_c[l][l], int res[l][l]) {
  int i, j;

  for(i = 0; i < l; i++) {
    for(j = 0; j < l; j++) {
      res[i][j] = (sol_p[i][j] != 0) ? sol_p[i][j] : sol_c[i][j];
    }
  }
}


/* Verifica daca sol este valida (pe linii si pe coloane) */
int check_solution(int l, int sol[l][l]) {
  int i, j, k;

  for(i = 0; i < l; i++) {
    for(j = 0; j < l; j++) {
      for(k = j + 1; k < l; k++) {
        if(sol[i][j] != 0 && sol[i][k] != 0 && sol[i][j] == sol[i][k])
          return 0;
      }
      for(k = i + 1; k < l; k++) {
        if(sol[i][j] != 0 && sol[k][j] != 0 && sol[i][j] == sol[k][j])
          return 0;
      }
    }
  }

  return 1;
}

/* Verifica daca sol este completa pentru nodul curent, adica daca
   a fost completata de totii copiii sai */
int complete_solution(int tabela_rutare[NP], int parinte, char *what_nodes) {
  int i;

  for(i = 0; i < NP; i++) {
    if(tabela_rutare[i] == i && i != parinte && !what_nodes[i]) {
      return 0;
    }
  }

  return 1;
}

/* Verifica daca in solutia partiala combined_res[index] a fost completata
   pozitia corespunzatoare nodului source */
int can_combine(int index, int source) {
  return combined_nodes[index][source] == 0;
}

/* Combina solutii partiale
   - dim_probl - latura unui patrat mic
   - no_res - numarul de rez partiale proprii
   - lat - latura patratului intreg
   - sol_recv - o solutie partiala primita
   - nr_nodes - numarul de noduri de pe ramura curenta (nr_copii + 1)
   - rank - rank-ul procesului
   - parent - parintele procesului 
   - source - sursa lui sol_recv */
void combine_results(int dim_probl, int no_res, int lat, 
                     int sol_recv[lat][lat], int rank, int parent,
                     int source, int tabela_rutare[NP]) {
  int i, k, ii, jj;
  int comb_res[lat][lat];
  int is_complete;

  //combin sol_recv cu toate solutiile partiale salvate in combined_res
  for(i = 0; i < no_cr; i++) {
    if(can_combine(i, source)) {
      combine(lat, combined_res[i], sol_recv, comb_res);
      //daca noua solutie este corecta
      if(check_solution(lat, comb_res)) {
        //verifica daca solutia este completa
        is_complete = 0;
        combined_nodes[i][source] = 1;
        is_complete = complete_solution(tabela_rutare, parent, combined_nodes[i]);
        combined_nodes[i][source] = 0;

        if(is_complete) {
          //trimit solutia la parinte
          if(parent != -1) {
            MPI_Send(comb_res, lat * lat, MPI_INT, parent, 1, MPI_COMM_WORLD);
          }
          else { //afisez rezultatul
            printf("I found a solution ...writing to file");
            write_solution(lat, comb_res);
            break;
          }
        } else { //daca solutia e buna dar nu completa, o adaug la combined_res
          k = no_cr;
          //redimensionez daca e nevoie
          if(k == max_cr) {
            combined_res = resize(combined_res, no_cr, &max_cr, lat);
            combined_nodes = resize_combined(no_cr, max_cr/2, max_cr);
          }
          for(ii = 0; ii < lat; ii++) {
            for(jj = 0; jj < lat; jj++) {
              combined_res[k][ii][jj] = comb_res[ii][jj];
            }
          }
          no_cr++;
          //marchez nodurile care au contribuit la solutie
          for(ii = 0; ii < NP; ii++) {
            combined_nodes[k][ii] = combined_nodes[i][ii];
          }
          combined_nodes[k][source] = 1;
        }
      }
    }
  }

}


int main(int argc, char *argv[]) {
  int  numtasks, rank, len, rc; 
  char hostname[MPI_MAX_PROCESSOR_NAME];

  rc = MPI_Init(&argc,&argv);
  if (rc != MPI_SUCCESS) {
    printf ("Error starting MPI program. Terminating.\n");
    MPI_Abort(MPI_COMM_WORLD, rc);
  }

  MPI_Comm comm = MPI_COMM_WORLD;
  MPI_Status status;
  MPI_Comm_size(MPI_COMM_WORLD,&numtasks);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  MPI_Get_processor_name(hostname, &len);
  printf ("Number of tasks= %d My rank= %d Running on %s\n", numtasks, rank, hostname);
  NP = numtasks;

  int top[NP][NP], top_nou[NP][NP], top_sonda[NP][NP], top_ecou_nula[NP][NP];
  int tabela_rutare[NP];
  int i, j, k, parinte, nr_vec = -1;
  int dim_probl = sqrt(numtasks);
  int child_info[NP]; // numarul de copii per branch
  int latura = NP , **my_square;
  int nr_ecouri;
  output_file = argv[3];

  //initializari
  for(i = 0; i < NP; i++) {
    child_info[i] = 0;
    tabela_rutare[i] = -1;
    for(j = 0; j < NP; j++) {
       top[i][j] = 0;
       top_nou[i][j] = 0;
       top_sonda[i][j] = -1;
       top_ecou_nula[i][j] = 0;
    }
  }

  nr_vec = read_neighbours(argv[1], top, rank);
  nr_ecouri = nr_vec;


  /************ Stabilire Topologie *************/

  if(rank == 0) {
    nr_ecouri++;
    parinte = -1;
  } else {
    //primeste mesaj de la parinte
    MPI_Recv(top_nou, NP * NP, MPI_INT, MPI_ANY_SOURCE, 1, comm, &status);
    parinte = status.MPI_SOURCE;
  }

  //trimite sonde la copii
  for(i = 0; i < NP; i++) {
    if(top[rank][i] == 1 && i != parinte) {
      MPI_Send(top_sonda, NP * NP, MPI_INT, i, 1, comm);
      }
  }


  //primesc raspunsuri
  while(nr_ecouri > 0) {
    MPI_Recv(top_nou, NP * NP, MPI_INT, MPI_ANY_SOURCE, 1, comm, &status);
    // daca e sonda, trimite raspuns o topologie nula
    if(top_nou[0][0] == -1) {
      MPI_Send(top_ecou_nula, NP * NP, MPI_INT, status.MPI_SOURCE, 1, comm); 
    } else { //daca e ecou, updateaza topologia proprie
      //updateaza topologia
      update(top, top_nou, parinte);
      //updateaza tabela de rutare
      update_tabela(top_nou, tabela_rutare, status.MPI_SOURCE);
      nr_ecouri --;
      child_info[status.MPI_SOURCE] = count_nodes_on_branch(top_nou);
    }
  }

   //marcheaza ruta catre toate nodurile la care nu se poate 
    //ajunge ca fiind prin parinte
  for(i = 0; i < NP; i++) {
    if(tabela_rutare[i] == -1)
      tabela_rutare[i] = parinte;
  }
  tabela_rutare[rank] = rank;

  if(rank == 0) {
    print_top(top, rank);
  } else {
    print_tabela(tabela_rutare, rank);

    //trimite topologia la parinte
    MPI_Send(top, NP * NP, MPI_INT, parinte, 1, comm);
  }

  /*********************** Calcul Sudoku ***********************/
  int sudoku_aux[latura][latura];
  int finished[NP]; //marcheaza copiii care au terminat de trimis solutiile partiale
  int send_matr[latura][latura];
  int sol_recv[latura][latura];
  int no_results, flag, all_received = 0, byte_amount, aux;


  if(rank == 0) {
    //citeste matricea din fisier
    sudoku = read_sudoku(argv[2], latura);

    for(i = 0; i < latura; i++) {
      for(j = 0; j < latura; j++) {
        sudoku_aux[i][j] = sudoku[i][j];
      }
    }

  } else {
    //primeste matricea de sudoku
    MPI_Recv(sudoku_aux, latura * latura, MPI_INT, parinte, 1, comm, &status);

    sudoku = (int **)malloc(latura * sizeof(int *));
    for(i = 0; i < latura; i++) {
      sudoku[i] = (int *)malloc(latura * sizeof(int));
      for(j = 0; j < latura; j++) {
        sudoku[i][j] = sudoku_aux[i][j];
      }
    }
    
    // primeste matricea ramasa nealocata
    MPI_Recv(sudoku_aux, latura * latura, MPI_INT, parinte, 1, comm, &status);
  }
  //alege patratul meu
  my_square = choose_square(latura, sudoku_aux, dim_probl);

  //trimite mai departe la copii
  send_matrix_to_children(top, rank, parinte, child_info, latura, sudoku_aux, dim_probl);

  //calculeaza numarul de copii din arborele STP
  nr_vec = 0;
  for(i = 0; i < NP; i++) {
    finished[i] = 0;
    if(child_info[i] != 0) nr_vec++; 
  }

  //initializari
  results = (int ***)malloc(MAX_SOL * sizeof(int **));
  for(i = 0; i < MAX_SOL; i++) {
    results[i] = (int **)malloc(dim_probl * sizeof(int *));
    for(j = 0; j < dim_probl; j++) {
      results[i][j] = (int *)malloc(dim_probl * sizeof(int));
    }
  }

  //calculeaza solutiile partiale proprii
  no_results = compute_my_solutions(dim_probl, my_square);

  //initializari
  combined_res = (int ***)malloc(2 * no_results * sizeof(int **));
  combined_nodes = (char **)malloc(2 * no_results * sizeof(char *));
  for(i = 0; i < 2 * no_results; i++) {
    combined_res[i] = (int **)malloc(latura * sizeof(int *));
    combined_nodes[i] = (char *)calloc(NP, sizeof(char));
    for(j = 0; j < latura; j++) {
      combined_res[i][j] = (int *)malloc(latura * sizeof(int));
    }
  }
  max_cr = 2 * no_results;

  //copiaza rezultatele partiale in tabloul combined_res
  int aux_m[latura][latura];
  for(i = 0; i < no_results; i++) {
    assemble_partial_sol(dim_probl, results[i], latura, aux_m);
      for(j = 0; j < latura; j++) {
        for(k = 0; k < latura; k++) {
          combined_res[i][j][k] = aux_m[j][k];
        }
      }
      combined_nodes[i][rank] = 1;
    }
  no_cr = no_results;


  //daca e frunza, trimite solutiile la parinte
  if(count_nodes_on_branch(top) == 1) {
    for(i = 0; i < no_results; i++) {
      assemble_partial_sol(dim_probl, results[i], latura, send_matr);
      MPI_Send(send_matr, latura * latura, MPI_INT, parinte, 1, comm);
    }
    //am terminat de transmis
    int fin = 0;
    MPI_Send(&fin, 1, MPI_INT, parinte, 1, comm);

  } else { //daca nu e frunza
      //primesc solutii partiale de la copii
      while(all_received < nr_vec) {
          MPI_Iprobe(MPI_ANY_SOURCE, 1, comm, &flag, &status);
          i = status.MPI_SOURCE;
          //daca i e copil si inca nu a terminat de trimis
          if(top[rank][i] && i != parinte && !finished[i]) {
            if(flag == 1) {
              MPI_Get_count(&status, MPI_INT, &byte_amount);
              //semnal de sfarsit de transmisie
              if(byte_amount == 1) {
                MPI_Recv(&aux, 1, MPI_INT, i, 1, comm, &status);
                finished[i] = 1;
                all_received ++;  
              } else {  //primeste solutie
                MPI_Recv(sol_recv, byte_amount, MPI_INT, i, 1, comm, &status);
                combine_results(dim_probl, no_results, latura, sol_recv,
                                rank, parinte, i, tabela_rutare);
              }
            }
          }
        
      }

      //trimite fin la parinte
      if(parinte != -1) {
        int fin = 0;
        MPI_Send(&fin, 1, MPI_INT, parinte, 1, comm);
      }
    }  

  MPI_Finalize();
  return 0;
}

