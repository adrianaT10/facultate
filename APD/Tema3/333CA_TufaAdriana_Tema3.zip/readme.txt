//Tufa Adriana 333 CA
//Tema 3 APD

Stabilirea topologiei:

  Pentru a descoperi topologia si a crea un arbore de acoperire am urmat algoritmul
prezentat in curs. Fiecare proces citeste din fisierul de topologie linia corespunzatoare
si isi marcheaza vecinii in matricea de adiacenta. Radacina initiaza algoritmul, trimitand
o cate o sonda la toti vecinii. Fiecare proces isi retine parintele ca fiind sursa primului
mesaj primit. Apoi trimite cate o sonda la toti copiii. Acum fiecare proces urmeaza sa
primeasca atatea ecouri cati copii are. Insa va primi si alte sonde daca in topologie
exista cicluri. Daca primeste sonda, trimite raspuns o topologie nula. Daca este ecou,
isi completeaza topologia proprie cu cea primita si updateaza tabela de rutare. La sfarsit
trimite topologia sa parintelui.
  Pentru o procesare mai rapida a etapei urmatoare am retinut, pe langa tabela de rutare,
un vector child_info care tine minte pentru fiecare proces copil, cate noduri exista pe
ramura respectiva, incluzand copilul. Acest lucru il fac cand primesc ecouri. O matrice
de topologie primita atunci are atatea noduri cate linii completate exista in ea.
  Procesul radacina afiseaza intreaga matrice de adiacenta iar celelalte procese vor afisa
tabela de rutare avand NP linii, iar fiecare linie fiind de forma destinatie - next hop.

Calculul sudoku:

  Procesul 0 citeste matricea data in fisier si isi alege patratul pe care il va rezolva.
Apoi trimite copiilor matricea citita si matricea cu pozitiile libere. Dupa ce trimite
unui copil, marcheaza ca ocupate atatea patrate cate noduri sunt pe ramura lui. Apoi
va trimite la urmatorul. Un patrat marcat ocupat are pozitiile cu valoarea -1. Mai departe
fiecare copil repeta procesul, dand matricea citita din fisier mai departe si marcand
locurile ramase libere pentru fiecare ramura. 
  Acum fiecare proces isi calculeaza solutiile proprii, folosind backtracking. La sfarsit
ele sunt copiate intr-un tbalou tridimensional in care vor fi retinute solutiile partiale
combinate. 
  Frunzele sunt primele care incep sa isi trimita solutiile la parinti. Fiecare nod, pe masura
ce primeste o solutie de la un copil, incearca sa o combine cu solutiile partiale salvate.
Daca se gaseste o noua solutie partiala valida, se adauga la sfarsitul tabloului sau este
trimisa imediat la parinte daca aceasta este completa pentru respectivul nod. Pentru a verifica
daca o solutie este completa si pentru a face combinarile mai eficient, pentru fiecare solutie
partiala tin un vector in care marchez ce noduri copii au contribuit la respectiva solutie.
Atunci cand primesc o solutie de la nodul x, voi combina doar cu solutiile partiale in care
nu e completata pozitia x. O solutie este completa atunci cand toti copiii sai au contribuit
la ea.
  Cand un proces a terminat de trimis solutiile, va trimite un mesaj de final la parinte, astfel
fiecare proces se opreste dupa ce toti copiii sai au terminat de trimis.
  
Exista situatia in care sursa termina combinarile si gaseste solutia in timp ce unele procese
mai au multe solutii de primit si combinat. Am implementat si varianta in care radacina trimite
un semnal de oprire la copii in momentul in care a terminat, insa pe testele date si pe topologiile
mele, acest lucru nu a scalat.