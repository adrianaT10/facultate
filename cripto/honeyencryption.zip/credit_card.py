import math
import random


class CreditCardInfo:
	def __init__(self):
		self.get_prefixes()
		self.get_total_probability()
		self.create_prefix_ordered_list()
		self.compute_prefixes_cdf()
		self.get_inverse_sample_table()

	def get_prefixes(self):
		with open('bin.txt', 'r') as bin:
			self.prefixes = eval(bin.read())

	"""
	Returneaza suma "greutatilor" prefixelor
	"""
	def get_total_probability(self):
		sum = 0
		for [r, l, w] in self.prefixes.values():
			sum += w
		self.total_prob = sum

	def create_prefix_ordered_list(self):
		self.prefix_order = sorted(self.prefixes, key = self.prefixes.get)

	"""
	Creeaza o tabela de CDF pentru prefixe
	"""
	def compute_prefixes_cdf(self):
		cumul_prob = 0
		prefix_cumul = {}
		for prefix in self.prefix_order:
			prefix_cumul[prefix] = cumul_prob
			cumul_prob += float(self.prefixes[prefix][2]) / self.total_prob
		self.prefix_cdf = prefix_cumul

	def get_inverse_sample_table(self):
		with open('inverse_table.txt', 'r') as f:
			self.inverse_table = eval(f.read())



"""
Calculeaza PDF pentru un mesaj = 10^(-d) / total_prob
(d = nr de cifre random)
"""
def PDF(m, card):
	prefix = list('******')
	for i in range(6):
		prefix[i] = m[i]
		prefix_str = ''.join(prefix)
		if prefix_str in card.prefixes:
			prefix_prob = 1.0 / card.total_prob
			random_digits = m[6 : -1]
			num_random = len(random_digits)
			prob = prefix_prob * math.pow(10, -num_random) 
			return prob
	print "Invalid credit card"
	return 0


def CDF(m, card):
	prefix = list('******')
	for i in range(6):
		prefix[i] = m[i]
		prefix_str = ''.join(prefix)
		if prefix_str in card.prefixes:
			range_degree = card.prefixes[prefix_str][0]
			random_digits = m[6 - range_degree : -1]
			num_random_digs = card.prefixes[prefix_str][1] - 7
			prefix_cumul = card.prefix_cdf[prefix_str]
			total_cumul = prefix_cumul + float(random_digits) * pow(10, -num_random_digs) / card.total_prob
			return total_cumul
	print "Invalid credit card"
	return -1

def next_message(m):
	base_number = int(m[:-1])
	return str(luhn(base_number + 1))


"""
Primeste un numar m si intoarce numarul avand ultima cifra checksum-ul
calculat conform teoremei lui Luhn
"""
def luhn(m):
	sum = 0
	for i in list(str(m)):
		sum += int(i)
	last = (9 * sum) % 10
	return m * 10 + last
