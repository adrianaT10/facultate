from credit_card import *
from encryption import *
import os
from random import randint

credit_card_info = CreditCardInfo()

credit_card_example = '4117700001669792'
secret_key = 2048101736616812280
guess_key =  2048101736616812280
#guess_key =  2048101736616458277
#guess_key =  3496328831800304765

seed = encode(credit_card_example, credit_card_info)
ciphertext = secret_key ^ seed

print 'CREDIT CARD: ' + credit_card_example
print 'SEED: ' + str(seed)
print 'CIPHERTEXT: ' + str(ciphertext)

decipher_seed = guess_key ^ ciphertext
print 'GUESSED SEED: ' + str(decipher_seed)

message = decode(decipher_seed, credit_card_info)
print 'MESSAGE: ' + message