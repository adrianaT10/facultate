import random
from credit_card import *

SEED_SPACE_LENGTH = 64
seed_space = 2**SEED_SPACE_LENGTH - 1

def encode(m, card):
	start = CDF(m, card) * seed_space
	end = int(start + PDF(m, card) * seed_space) - 1
	start = int(start)

	seed = int(random.random() * (end - start) + start)
	return seed

def decode(s, card):
	table = card.inverse_table
	seed_loc = float(s) / seed_space
	(prev_value, prev_msg) = binary_search(table, 0, len(table), seed_loc)
	next_msg = next_message(prev_msg)
	next_value = CDF(next_msg, card)

	if next_msg == prev_msg:
		return prev_msg

	while seed_loc >= next_value:
		(prev_value, prev_msg) = (next_value, next_msg)
		next_msg = next_message(prev_msg)
		next_value = CDF(next_msg, card)
		#print str(seed_loc) + '  ' + str(next_value)
		if next_msg == prev_msg:
			return prev_msg

	return prev_msg

def binary_search(table, start, end, value):
	size = end - start

	if size == 1 or size == 0:
		return table[start]

	mid = start + size / 2
	(mid_value, mid_msg) = table[mid]

	if value >= mid_value:
		return binary_search(table, mid, end, value)
	else:
		return binary_search(table, start, mid, value)
