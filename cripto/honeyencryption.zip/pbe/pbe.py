import Crypto.Random
from Crypto.Cipher import AES
import hashlib

SALT_SIZE = 12
NO_ITERATIONS = 20
AES_MULTIPLE = 16

def generate_key(password, salt, iterations):
	key = password + salt
	for i in range(iterations):
		key = hashlib.sha256(key).digest()

	return key

def encrypt(plaintext, password):
	salt = Crypto.Random.get_random_bytes(SALT_SIZE)
	key = generate_key(password, salt, NO_ITERATIONS)
	cipher = AES.new(key, AES.MODE_ECB)
	ciphertext = cipher.encrypt(plaintext)
	ciphertext_with_salt = salt + ciphertext

	return ciphertext_with_salt

def decrypt(ciphertext, password):
	salt = ciphertext[0:SALT_SIZE]
	ciphertext_sans_salt = ciphertext[SALT_SIZE:]
	key = generate_key(password, salt, NO_ITERATIONS)
	cipher = AES.new(key, AES.MODE_ECB)
	plaintext = cipher.decrypt(ciphertext_sans_salt)
	return plaintext

def pad_text(text, multiple):
	extra_bytes = len(text) % multiple
	padding_size = multiple - extra_bytes
	padding = chr(padding_size) * padding_size
	padded_text = text + padding
	return padded_text

def unpad_text(padded_text):
	padding_size = ord(padded_text[-1])
	text = padded_text[:-padding_size]
	return text

def main():
	c = encrypt("4117700001669792", "1234")
	print "CIPHERTEXT: " + c
	d = decrypt(c, "1234")
	print "PLAINTEXT: " + d
	f = open("out.txt", 'w')
	password = ['0', '0', '0', '0']
	for i in range(10):
		password[0] = str(i)
		for i2 in range(10):
			password[1] = str(i2)
			for i3 in range(10):
				password[2] = str(i3)
				for i4 in range(10):
					password[3] = str(i4)
					d = decrypt(c, ''.join(password))
					f.write(d + '\n')
	


if __name__ == "__main__":
	main()
