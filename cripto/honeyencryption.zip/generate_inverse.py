# generate_inverse_table.py

# Generates inverse sampling table for the credit card space


from credit_card import *

'''
prefixes = {
    '5235**': [2, 8, 100],
    '123456': [0, 8, 1]
}
'''
card = CreditCardInfo()
table = open('inverse_table_1.txt','w')

for prefix in card.prefix_order:
    #'******'
    prefixList = list(prefix)
    prefix_cumul_prob = card.prefix_cdf[prefix]
    prefix_length = card.prefixes[prefix][1]
    degs_freedom = prefix.count('*')
    for i in range(10**degs_freedom):
        paddedStr = str(i).zfill(degs_freedom)
        for k in range(degs_freedom):
            prefixList[6-degs_freedom+k] = paddedStr[k] 
        newPrefix = ''.join(prefixList)
        m = str(luhn(int(newPrefix+'0'*(prefix_length-7))))
        cumul_prob = CDF(m, card)
        table.write('('+str(cumul_prob)+',"'+str(m)+'"),\n')
